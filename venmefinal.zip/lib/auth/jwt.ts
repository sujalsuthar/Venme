import { jwtVerify, SignJWT } from "jose"

// In a real app, these would be environment variables
const JWT_SECRET = new TextEncoder().encode("your-secret-key")
const JWT_EXPIRY = "7d"

export type UserRole = "customer" | "owner"

export interface UserJwtPayload {
  id: string
  email: string
  name: string
  role: UserRole
}

export async function signJwt(payload: UserJwtPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(JWT_EXPIRY)
    .sign(JWT_SECRET)
}

export async function verifyJwt(token: string): Promise<UserJwtPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return payload as UserJwtPayload
  } catch (error) {
    console.error("JWT verification failed:", error)
    return null
  }
}

export function setAuthCookie(token: string): void {
  document.cookie = `auth_token=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Strict`
}

export function getAuthCookie(): string | null {
  const cookies = document.cookie.split(";")
  const authCookie = cookies.find((cookie) => cookie.trim().startsWith("auth_token="))
  return authCookie ? authCookie.split("=")[1] : null
}

export function removeAuthCookie(): void {
  document.cookie = "auth_token=; path=/; max-age=0; SameSite=Strict"
}

