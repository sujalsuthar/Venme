"use client"

import { useContext } from "react"
import { WatchlistContext } from "../providers/watchlist-provider"

export const useWatchlist = () => {
  const context = useContext(WatchlistContext)

  if (!context) {
    throw new Error("useWatchlist must be used within a WatchlistProvider")
  }

  return context
}

