"use client"

import { useState, useEffect, createContext, useContext, createElement, type ReactNode } from "react"
import { useOwnerAuth } from "./use-owner-auth"
import { useOwnerListings } from "./use-owner-listings"

// Types
interface OwnerBooking {
  id: string
  listingId: string
  plotName: string
  location: string
  customerName: string
  customerEmail: string
  customerPhone: string
  date: string
  status: "pending" | "confirmed" | "cancelled"
  amount: number
  createdAt: string
}

interface OwnerBookingsContextType {
  bookings: OwnerBooking[]
  updateBookingStatus: (id: string, status: "pending" | "confirmed" | "cancelled") => void
}

// Create context
export const OwnerBookingsContext = createContext<OwnerBookingsContextType | null>(null)

// Provider component
export function OwnerBookingsProvider({ children }: { children: ReactNode }) {
  const { owner } = useOwnerAuth()
  const { listings } = useOwnerListings()
  const [bookings, setBookings] = useState<OwnerBooking[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Generate mock bookings based on listings
    if (listings.length > 0 && !localStorage.getItem("ownerBookings")) {
      const mockBookings: OwnerBooking[] = []

      // Generate some bookings for each listing
      listings.forEach((listing) => {
        // Confirmed bookings
        for (let i = 0; i < 3; i++) {
          const date = new Date()
          date.setDate(date.getDate() + Math.floor(Math.random() * 30) + 1)

          mockBookings.push({
            id: Math.random().toString(36).substring(2, 11),
            listingId: listing.id,
            plotName: listing.name,
            location: listing.location,
            customerName: ["Rahul Sharma", "Priya Patel", "Amit Kumar", "Neha Gupta", "Vikram Singh"][
              Math.floor(Math.random() * 5)
            ],
            customerEmail: "customer@example.com",
            customerPhone: "+91 98765 43210",
            date: date.toISOString(),
            status: "confirmed",
            amount: listing.price,
            createdAt: new Date(Date.now() - Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000).toISOString(),
          })
        }

        // Pending bookings
        for (let i = 0; i < 2; i++) {
          const date = new Date()
          date.setDate(date.getDate() + Math.floor(Math.random() * 30) + 1)

          mockBookings.push({
            id: Math.random().toString(36).substring(2, 11),
            listingId: listing.id,
            plotName: listing.name,
            location: listing.location,
            customerName: ["Rahul Sharma", "Priya Patel", "Amit Kumar", "Neha Gupta", "Vikram Singh"][
              Math.floor(Math.random() * 5)
            ],
            customerEmail: "customer@example.com",
            customerPhone: "+91 98765 43210",
            date: date.toISOString(),
            status: "pending",
            amount: listing.price,
            createdAt: new Date(Date.now() - Math.floor(Math.random() * 7) * 24 * 60 * 60 * 1000).toISOString(),
          })
        }

        // Cancelled bookings
        for (let i = 0; i < 1; i++) {
          const date = new Date()
          date.setDate(date.getDate() + Math.floor(Math.random() * 30) + 1)

          mockBookings.push({
            id: Math.random().toString(36).substring(2, 11),
            listingId: listing.id,
            plotName: listing.name,
            location: listing.location,
            customerName: ["Rahul Sharma", "Priya Patel", "Amit Kumar", "Neha Gupta", "Vikram Singh"][
              Math.floor(Math.random() * 5)
            ],
            customerEmail: "customer@example.com",
            customerPhone: "+91 98765 43210",
            date: date.toISOString(),
            status: "cancelled",
            amount: listing.price,
            createdAt: new Date(Date.now() - Math.floor(Math.random() * 14) * 24 * 60 * 60 * 1000).toISOString(),
          })
        }
      })

      setBookings(mockBookings)
      localStorage.setItem("ownerBookings", JSON.stringify(mockBookings))
    } else {
      // Load bookings from localStorage
      const storedBookings = localStorage.getItem("ownerBookings")
      if (storedBookings) {
        try {
          setBookings(JSON.parse(storedBookings))
        } catch (error) {
          console.error("Failed to parse bookings from localStorage:", error)
          localStorage.removeItem("ownerBookings")
        }
      }
    }
  }, [listings])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("ownerBookings", JSON.stringify(bookings))
    }
  }, [bookings, mounted])

  const updateBookingStatus = (id: string, status: "pending" | "confirmed" | "cancelled") => {
    setBookings((prev) => prev.map((booking) => (booking.id === id ? { ...booking, status } : booking)))
  }

  // Create the context value object
  const filteredBookings = owner
    ? bookings.filter((booking) =>
        listings.some((listing) => listing.id === booking.listingId && listing.ownerId === owner.id),
      )
    : []

  const contextValue = {
    bookings: filteredBookings,
    updateBookingStatus,
  }

  // Use createElement instead of JSX
  return createElement(OwnerBookingsContext.Provider, { value: contextValue }, children)
}

// Hook
export function useOwnerBookings() {
  const context = useContext(OwnerBookingsContext)

  if (!context) {
    throw new Error("useOwnerBookings must be used within an OwnerBookingsProvider")
  }

  return context
}

