"use client"

import { useState, useEffect, createContext, useContext, createElement, type ReactNode } from "react"
import { useOwnerAuth } from "./use-owner-auth"

// Types
interface OwnerListing {
  id: string
  ownerId: string
  name: string
  description: string
  location: string
  price: number
  capacity: number
  amenities: string[]
  image: string
  active: boolean
  createdAt: string
}

interface OwnerListingsContextType {
  listings: OwnerListing[]
  addListing: (listing: Omit<OwnerListing, "id" | "ownerId">) => void
  updateListing: (id: string, listing: Partial<OwnerListing>) => void
  removeListing: (id: string) => void
  toggleListingStatus: (id: string) => void
}

// Mock data
const mockListings: OwnerListing[] = [
  {
    id: "1",
    ownerId: "1",
    name: "Royal Garden Party Plot",
    description: "A luxurious party plot with beautiful gardens and modern amenities.",
    location: "Mumbai, Maharashtra",
    price: 25000,
    capacity: 500,
    amenities: ["parking", "catering", "decoration", "sound"],
    image: "/placeholder.svg?height=400&width=600",
    active: true,
    createdAt: "2023-01-15T10:30:00Z",
  },
  {
    id: "2",
    ownerId: "1",
    name: "Sunset Beach Venue",
    description: "Beachfront venue with stunning sunset views and open-air seating.",
    location: "Goa",
    price: 35000,
    capacity: 300,
    amenities: ["parking", "catering", "sound"],
    image: "/placeholder.svg?height=400&width=600",
    active: true,
    createdAt: "2023-02-20T14:45:00Z",
  },
  {
    id: "3",
    ownerId: "1",
    name: "Mountain View Resort",
    description: "Scenic mountain resort with panoramic views and luxury accommodations.",
    location: "Shimla, Himachal Pradesh",
    price: 40000,
    capacity: 250,
    amenities: ["parking", "catering", "decoration"],
    image: "/placeholder.svg?height=400&width=600",
    active: false,
    createdAt: "2023-03-10T09:15:00Z",
  },
]

// Create context
export const OwnerListingsContext = createContext<OwnerListingsContextType | null>(null)

// Provider component
export function OwnerListingsProvider({ children }: { children: ReactNode }) {
  const { owner } = useOwnerAuth()
  const [listings, setListings] = useState<OwnerListing[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Load listings from localStorage or use mock data
    const storedListings = localStorage.getItem("ownerListings")
    if (storedListings) {
      try {
        setListings(JSON.parse(storedListings))
      } catch (error) {
        console.error("Failed to parse listings from localStorage:", error)
        setListings(mockListings)
        localStorage.setItem("ownerListings", JSON.stringify(mockListings))
      }
    } else {
      setListings(mockListings)
      localStorage.setItem("ownerListings", JSON.stringify(mockListings))
    }
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("ownerListings", JSON.stringify(listings))
    }
  }, [listings, mounted])

  const addListing = (listing: Omit<OwnerListing, "id" | "ownerId">) => {
    if (!owner) return

    const newListing: OwnerListing = {
      ...listing,
      id: Math.random().toString(36).substring(2, 11),
      ownerId: owner.id,
    }

    setListings((prev) => [...prev, newListing])
  }

  const updateListing = (id: string, updatedFields: Partial<OwnerListing>) => {
    setListings((prev) => prev.map((listing) => (listing.id === id ? { ...listing, ...updatedFields } : listing)))
  }

  const removeListing = (id: string) => {
    setListings((prev) => prev.filter((listing) => listing.id !== id))
  }

  const toggleListingStatus = (id: string) => {
    setListings((prev) =>
      prev.map((listing) => (listing.id === id ? { ...listing, active: !listing.active } : listing)),
    )
  }

  // Create the context value object
  const contextValue = {
    listings: owner ? listings.filter((listing) => listing.ownerId === owner.id) : [],
    addListing,
    updateListing,
    removeListing,
    toggleListingStatus,
  }

  // Use createElement instead of JSX
  return createElement(OwnerListingsContext.Provider, { value: contextValue }, children)
}

// Hook
export function useOwnerListings() {
  const context = useContext(OwnerListingsContext)

  if (!context) {
    throw new Error("useOwnerListings must be used within an OwnerListingsProvider")
  }

  return context
}

