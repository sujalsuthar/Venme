"use client"

import { useState, useEffect, createContext, useContext, createElement, type ReactNode } from "react"

// Types
interface Owner {
  id: string
  name: string
  email: string
  phone?: string
  address?: string
  company?: string
  createdAt: string
}

interface OwnerSettings {
  emailNotifications: boolean
  smsNotifications: boolean
  pushNotifications: boolean
  twoFactorAuth: boolean
}

interface OwnerAuthContextType {
  owner: Owner | null
  isAuthenticated: () => boolean
  login: (email: string, password: string) => boolean
  signup: (name: string, email: string, password: string) => boolean
  logout: () => void
  updateOwnerProfile: (profileData: Partial<Owner>) => void
  updateOwnerSettings: (settings: Partial<OwnerSettings>) => void
}

// Mock data
const mockOwners = [
  {
    id: "1",
    name: "John Doe",
    email: "owner@example.com",
    password: "password123",
    phone: "+91 98765 43210",
    address: "123 Main St, Mumbai, India",
    company: "Party Plots Inc.",
    createdAt: "2023-01-01T00:00:00Z",
  },
]

// Create context
export const OwnerAuthContext = createContext<OwnerAuthContextType | null>(null)

// Provider component
export function OwnerAuthProvider({ children }: { children: ReactNode }) {
  const [owner, setOwner] = useState<Owner | null>(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Check if user is logged in
    const storedOwner = localStorage.getItem("owner")
    if (storedOwner) {
      try {
        setOwner(JSON.parse(storedOwner))
      } catch (error) {
        console.error("Failed to parse owner from localStorage:", error)
        localStorage.removeItem("owner")
      }
    }
  }, [])

  const isAuthenticated = () => {
    return !!owner
  }

  const login = (email: string, password: string) => {
    // In a real app, this would make an API call
    const foundOwner = mockOwners.find((o) => o.email === email && o.password === password)

    if (foundOwner) {
      const { password, ...ownerWithoutPassword } = foundOwner
      setOwner(ownerWithoutPassword)
      localStorage.setItem("owner", JSON.stringify(ownerWithoutPassword))
      return true
    }

    return false
  }

  const signup = (name: string, email: string, password: string) => {
    // Check if email already exists
    const existingOwner = mockOwners.find((o) => o.email === email)
    if (existingOwner) {
      return false
    }

    // In a real app, this would make an API call
    const newOwner = {
      id: Math.random().toString(36).substring(2, 11),
      name,
      email,
      createdAt: new Date().toISOString(),
    }

    setOwner(newOwner)
    localStorage.setItem("owner", JSON.stringify(newOwner))

    // Add to mock data (in a real app, this would be handled by the backend)
    mockOwners.push({ ...newOwner, password })

    return true
  }

  const logout = () => {
    setOwner(null)
    localStorage.removeItem("owner")
  }

  const updateOwnerProfile = (profileData: Partial<Owner>) => {
    if (owner) {
      const updatedOwner = { ...owner, ...profileData }
      setOwner(updatedOwner)
      localStorage.setItem("owner", JSON.stringify(updatedOwner))
    }
  }

  const updateOwnerSettings = (settings: Partial<OwnerSettings>) => {
    // In a real app, this would make an API call to update settings
    console.log("Updating settings:", settings)
  }

  // Create the context value object
  const contextValue = {
    owner,
    isAuthenticated,
    login,
    signup,
    logout,
    updateOwnerProfile,
    updateOwnerSettings,
  }

  // Use createElement instead of JSX
  return createElement(OwnerAuthContext.Provider, { value: contextValue }, children)
}

// Hook
export function useOwnerAuth() {
  const context = useContext(OwnerAuthContext)

  if (!context) {
    throw new Error("useOwnerAuth must be used within an OwnerAuthProvider")
  }

  return context
}

