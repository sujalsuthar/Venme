"use client"

import { useContext } from "react"
import { BookingsContext } from "../providers/bookings-provider"

export const useBookings = () => {
  const context = useContext(BookingsContext)

  if (!context) {
    throw new Error("useBookings must be used within a BookingsProvider")
  }

  return context
}

