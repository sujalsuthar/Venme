"use client"

import { useContext } from "react"
import { RecentlyViewedContext } from "../providers/recently-viewed-provider"

export const useRecentlyViewed = () => {
  const context = useContext(RecentlyViewedContext)

  if (!context) {
    throw new Error("useRecentlyViewed must be used within a RecentlyViewedProvider")
  }

  return context
}

