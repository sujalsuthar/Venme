"use client"

import { createContext, useState, useEffect, createElement, type ReactNode } from "react"
import type { Listing } from "../types"

interface CartContextType {
  cart: Listing[]
  addToCart: (listing: Listing) => void
  removeFromCart: (id: string) => void
  isInCart: (id: string) => boolean
  clearCart: () => void
}

export const CartContext = createContext<CartContextType | null>(null)

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [cart, setCart] = useState<Listing[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const storedCart = localStorage.getItem("cart")
    if (storedCart) {
      try {
        setCart(JSON.parse(storedCart))
      } catch (error) {
        console.error("Failed to parse cart from localStorage:", error)
        localStorage.removeItem("cart")
      }
    }
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("cart", JSON.stringify(cart))
    }
  }, [cart, mounted])

  const addToCart = (listing: Listing) => {
    if (!isInCart(listing.id)) {
      setCart((prev) => [...prev, listing])
    }
  }

  const removeFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id))
  }

  const isInCart = (id: string) => {
    return cart.some((item) => item.id === id)
  }

  const clearCart = () => {
    setCart([])
  }

  // Create the context value object
  const contextValue = {
    cart,
    addToCart,
    removeFromCart,
    isInCart,
    clearCart,
  }

  // Use createElement instead of JSX
  return createElement(CartContext.Provider, { value: contextValue }, children)
}

