"use client"

import { createContext, useState, useEffect, useContext, createElement, type ReactNode } from "react"
import type { Listing } from "../types"

interface FavoritesContextType {
  favorites: Listing[]
  addToFavorites: (listing: Listing) => void
  removeFromFavorites: (id: string) => void
  isInFavorites: (id: string) => boolean
  clearFavorites: () => void
}

export const FavoritesContext = createContext<FavoritesContextType | null>(null)

// Add the missing useFavorites hook
export const useFavorites = () => {
  const context = useContext(FavoritesContext)
  if (!context) {
    throw new Error("useFavorites must be used within a FavoritesProvider")
  }
  return context
}

export const FavoritesProvider = ({ children }: { children: ReactNode }) => {
  const [favorites, setFavorites] = useState<Listing[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const storedFavorites = localStorage.getItem("favorites")
    if (storedFavorites) {
      try {
        setFavorites(JSON.parse(storedFavorites))
      } catch (error) {
        console.error("Failed to parse favorites from localStorage:", error)
        localStorage.removeItem("favorites")
      }
    }
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("favorites", JSON.stringify(favorites))
    }
  }, [favorites, mounted])

  const addToFavorites = (listing: Listing) => {
    setFavorites((prev) => {
      if (prev.some((item) => item.id === listing.id)) {
        return prev
      }
      return [...prev, listing]
    })
  }

  const removeFromFavorites = (id: string) => {
    setFavorites((prev) => prev.filter((item) => item.id !== id))
  }

  const isInFavorites = (id: string) => {
    return favorites.some((item) => item.id === id)
  }

  const clearFavorites = () => {
    setFavorites([])
  }

  // Create the context value object
  const contextValue = {
    favorites,
    addToFavorites,
    removeFromFavorites,
    isInFavorites,
    clearFavorites,
  }

  // Use createElement instead of JSX
  return createElement(FavoritesContext.Provider, { value: contextValue }, children)
}

