"use client"

import { createContext, useState, useEffect, createElement, type ReactNode } from "react"
import type { Booking } from "../types"

interface BookingsContextType {
  bookings: Booking[]
  addBooking: (booking: Booking) => void
  removeBooking: (id: string) => void
  clearBookings: () => void
}

export const BookingsContext = createContext<BookingsContextType | null>(null)

export const BookingsProvider = ({ children }: { children: ReactNode }) => {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const storedBookings = localStorage.getItem("bookings")
    if (storedBookings) {
      try {
        setBookings(JSON.parse(storedBookings))
      } catch (error) {
        console.error("Failed to parse bookings from localStorage:", error)
        localStorage.removeItem("bookings")
      }
    }
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("bookings", JSON.stringify(bookings))
    }
  }, [bookings, mounted])

  const addBooking = (booking: Booking) => {
    setBookings((prev) => [...prev, booking])
  }

  const removeBooking = (id: string) => {
    setBookings((prev) => prev.filter((booking) => booking.id !== id))
  }

  const clearBookings = () => {
    setBookings([])
  }

  // Create the context value object
  const contextValue = {
    bookings,
    addBooking,
    removeBooking,
    clearBookings,
  }

  // Use createElement instead of JSX
  return createElement(BookingsContext.Provider, { value: contextValue }, children)
}

