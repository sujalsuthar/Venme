"use client"

import { createContext, useState, useEffect, createElement, type ReactNode } from "react"
import type { Listing } from "../types"

interface WatchlistContextType {
  watchlist: Listing[]
  addToWatchlist: (listing: Listing) => void
  removeFromWatchlist: (id: string) => void
  isInWatchlist: (id: string) => boolean
  clearWatchlist: () => void
}

export const WatchlistContext = createContext<WatchlistContextType | null>(null)

export const WatchlistProvider = ({ children }: { children: ReactNode }) => {
  const [watchlist, setWatchlist] = useState<Listing[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const storedWatchlist = localStorage.getItem("watchlist")
    if (storedWatchlist) {
      try {
        setWatchlist(JSON.parse(storedWatchlist))
      } catch (error) {
        console.error("Failed to parse watchlist from localStorage:", error)
        localStorage.removeItem("watchlist")
      }
    }
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("watchlist", JSON.stringify(watchlist))
    }
  }, [watchlist, mounted])

  const addToWatchlist = (listing: Listing) => {
    if (!isInWatchlist(listing.id)) {
      setWatchlist((prev) => [...prev, listing])
    }
  }

  const removeFromWatchlist = (id: string) => {
    setWatchlist((prev) => prev.filter((item) => item.id !== id))
  }

  const isInWatchlist = (id: string) => {
    return watchlist.some((item) => item.id === id)
  }

  const clearWatchlist = () => {
    setWatchlist([])
  }

  // Create the context value object
  const contextValue = {
    watchlist,
    addToWatchlist,
    removeFromWatchlist,
    isInWatchlist,
    clearWatchlist,
  }

  // Use createElement instead of JSX
  return createElement(WatchlistContext.Provider, { value: contextValue }, children)
}

