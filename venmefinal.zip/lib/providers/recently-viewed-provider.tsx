"use client"

import { createContext, useState, useEffect, createElement, type ReactNode } from "react"
import type { Listing } from "../types"

interface RecentlyViewedContextType {
  recentlyViewed: Listing[]
  addToRecentlyViewed: (listing: Listing) => void
  clearRecentlyViewed: () => void
}

export const RecentlyViewedContext = createContext<RecentlyViewedContextType | null>(null)

export const RecentlyViewedProvider = ({ children }: { children: ReactNode }) => {
  const [recentlyViewed, setRecentlyViewed] = useState<Listing[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const storedRecentlyViewed = localStorage.getItem("recentlyViewed")
    if (storedRecentlyViewed) {
      try {
        setRecentlyViewed(JSON.parse(storedRecentlyViewed))
      } catch (error) {
        console.error("Failed to parse recently viewed from localStorage:", error)
        localStorage.removeItem("recentlyViewed")
      }
    }
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem("recentlyViewed", JSON.stringify(recentlyViewed))
    }
  }, [recentlyViewed, mounted])

  const addToRecentlyViewed = (listing: Listing) => {
    setRecentlyViewed((prev) => {
      // Remove if already exists
      const filtered = prev.filter((item) => item.id !== listing.id)
      // Add to beginning of array (most recent first)
      return [listing, ...filtered].slice(0, 8) // Keep only 8 most recent
    })
  }

  const clearRecentlyViewed = () => {
    setRecentlyViewed([])
  }

  // Create the context value object
  const contextValue = {
    recentlyViewed,
    addToRecentlyViewed,
    clearRecentlyViewed,
  }

  // Use createElement instead of JSX
  return createElement(RecentlyViewedContext.Provider, { value: contextValue }, children)
}

