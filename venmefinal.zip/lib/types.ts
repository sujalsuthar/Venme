export interface Listing {
  id: string
  name: string
  location: string
  price: number
  rating: number
  image: string
  capacity: number
  amenities: string[]
  description?: string
  discount?: number
  trending?: boolean
}

export interface Booking {
  id: string
  plotName: string
  location: string
  eventDate: string
  status: "pending" | "confirmed" | "cancelled"
  price: number
}

