import type { Listing } from "./types"

export const listings: Listing[] = [
  {
    id: "lotus-banquet",
    name: "The Grand Lotus Banquets",
    location: "Near Nayara Petrol Pump, Sarkhej-Gandhinagar Highway, Ahmedabad",
    price: 67500,
    rating: 4.9,
    image:
      "https://media-hosting.imagekit.io//63a46695cb304f82/4.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=IYr49cfJpNzNpgCCCW5m~yarhqtZ1ORotWGYYRO30sWA95sm1ZA2t~gP2OsJOkZAGFU7Z471vX7UfFLJcieYiunp3IHx7l0F0WQp4d5~e-Y~9jmLiONnvoVaHy1-6uFWPJvHWTyk2SD5OzxPvccrv0-X7BSxCcAVmjfBWK7z5hsXd1bh333nA-oXBXUgPA37oVmPMPsNdAhSGW7-~JE14YvBAzYReOF~01cnLB413cq5TCpdfp0imw0vMcwZvSvPddyDdp0xV-txEgqCjsbmRC1SwG0DRjP0awbr3uG-XIvd2LHfBVFtvCgW6LjRkH~sf3bPnYhaqpVVKj6hTyLW6w__",
    capacity: 800,
    amenities: ["parking", "catering", "decoration", "sound", "accommodation", "pool"],
    description:
      "The Grand Lotus Banquets is a premier venue for weddings, corporate events, and celebrations. With its stunning architecture, luxurious interiors, and impeccable service, it offers an unforgettable experience for all occasions. The venue features multiple halls, outdoor spaces, and a dedicated team to ensure your event is perfect.",
    discount: 0,
    trending: true,
  },
  {
    id: "1",
    name: "Royal Garden Party Plot",
    location: "Mumbai, Maharashtra",
    price: 25000,
    rating: 4.8,
    image:
      "https://media-hosting.imagekit.io//c1c33d76c2c94010/10.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=dl~PxTAFyIlpRpJ3jqmqX7fD-2nQrM~3B3VKQAByn6ofcDjl~tF4i4FO0gNtR2SYGS7tDEvCakMWEb1P-bWgWhNgqTVCGldM2csRxRlXCZoEQkFrP2LfbBKQ1oST5B8IueMD4~w4NRCTh2l9sEWi3Q-hO00YBAf7vq4IfRXOm~plsflUllpzjM9dkegSjyq8h8qG7h3bRmkseOBjzXxJEe2ejneNS3NoCgUiQ3BU0frrRZicibypK8XNVwknNKKd9TW1Pea6C0aOWGd3Irw7DFqkg4yZT12ZYzHr9braT1MDjBY741WJ6CHt88cscLSAt1DG0jKSDranSv7RpKmRpQ__",
    capacity: 500,
    amenities: ["parking", "catering", "decoration", "sound"],
    description:
      "A luxurious party plot with beautiful gardens and modern amenities. Perfect for weddings, corporate events, and large gatherings. The venue features elegant decor, spacious halls, and professional staff to ensure your event is a success.",
    discount: 15,
    trending: true,
  },
  {
    id: "2",
    name: "Sunset Beach Venue",
    location: "Goa",
    price: 35000,
    rating: 4.9,
    image:
      "https://media-hosting.imagekit.io//5ebd30a3302245c6/11.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=JNH1Ot9RfZqpCGby0bz4kHL6s034YxFOzVw5fM4m-uXOpREv5LqSFZYYAikEkEqrRkcV5BeWvI5wF879h0tA9SmSVahzrSopwKbvn9F~h-5VyPPDEiPYRfcDokwwmLsgpOYKq-GFKxiemJvn7CYfBvh3h9fMA6eSNRf~39Yx5zLytjUNqgGehyTMtTQGrYcQHT-z9gFvfA6VRPee1bw-4fezlWLcWd3LMjFsVQleAZA1IfF69fiPY9ZXfSeDvvCeH0rRYNxXFZwqJ1ljJaxVKgmpDzB5J7vxXS0WhhXfD1Qp26FQHOM8O5CbmixEVJTUCvHWuz62DQgraerKLhF1-Q__",
    capacity: 300,
    amenities: ["parking", "catering", "sound"],
    description:
      "Beachfront venue with stunning sunset views and open-air seating. This beautiful beachside location offers a perfect backdrop for weddings and parties with its golden sands and panoramic ocean views. Includes beach decoration and sound system.",
    discount: 0,
  },
  {
    id: "3",
    name: "Mountain View Resort",
    location: "Shimla, Himachal Pradesh",
    price: 40000,
    rating: 4.7,
    image:
      "https://media-hosting.imagekit.io//2387a3d4018d45de/12.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=w078i7b64IYA~9QGEn~iBXs2n~j8liht3uy1IiADa7WdFgt-ZCrD6EyEvBhSI712omrj0bDDGcH5dQAgfNez-E3HgtN-KZuuRt-c9p05PdsHdGx4h7Iwr3r1lXLGg~WEUnpStRQJFAQX3E~5oOOkMCh4AFvhpba1OC15lDk1W1kXiHl~FgXT8Rv70kDbbH0nlxOMHgSYtNwczMvtEhYDFIfSnAhHO4vmGfPIDPRM79Kvg7JEFZ2uSyj6MS7jbHjKcllrbUPiEDVsRXh8Eo4noDTmNR0Uzj8jG~E2K4JpWEzZQRMX2740DhizaTQ6ZaAZl4wiThRLWUROUEHjgtWnXg__",
    capacity: 250,
    amenities: ["parking", "catering", "decoration"],
    description:
      "Scenic mountain resort with panoramic views and luxury accommodations. Nestled in the Himalayan foothills, this venue offers breathtaking views, cool climate, and excellent facilities for destination weddings and corporate retreats.",
    discount: 10,
  },
  {
    id: "4",
    name: "City Lights Banquet",
    location: "Delhi",
    price: 30000,
    rating: 4.6,
    image:
      "https://media-hosting.imagekit.io//844ea8ff46f74624/7.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=py~~P32BDzIhUMmDCFz0DnjvbOPpubBXDhlwcO54A78mDuKB9vrV4K~33me3h0pbjB~r-5UaJLEppDYqlERvY4kf-vh7Y8ZLJQGkgXRldxUE4YO2TBMWrARX7xwmBXlwa0wNhb8tuYIfOl4R82PK3pf7ljARVMPO4JQaZINRSzjqAm95xHxnHLN2Fv~5BhhEY14u65vYCKke1UXcU834bFHwjtwaDBHxhmjuAGlLcyZ03amjKtvgqqtCgs1vw1Uiuw0nv-f7ZZPtL072JU~x9bep6BZHgj~AJKLMrXdb9GdrM7FHKIbUbcuRtN08osWSX3U8VFaqOhqnF9J3v4Ug-A__",
    capacity: 400,
    amenities: ["parking", "catering", "decoration", "sound"],
    description:
      "Urban banquet hall with modern decor and city skyline views. Located in the heart of Delhi, this sophisticated venue offers state-of-the-art facilities, customizable spaces, and professional event management services.",
    discount: 5,
    trending: true,
  },
  {
    id: "5",
    name: "Heritage Palace",
    location: "Jaipur, Rajasthan",
    price: 50000,
    rating: 4.9,
    image:
      "https://media-hosting.imagekit.io//c5be07ec0c524a4e/6.png?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=yztd~KJO1f42IurYUBHJ9aWp2HRtxvD9asSubAsDOgRNm2Ac5T5QY2lJz0YOAP78Q9G8cE2uHuJ1k3aodxF5vac6Yh0pIvlnBkKqoExm3mCqBdOPVzzm1AfFLOUMKAE2TAUa38UangXbVvVPnIYVMD3zyDrMXbqoWODa9geRAVNj~izEGAjHCDhp6uNt9NHOH1myg8pEzghPkgXXuA6zzU1j5mSCOSFUL9UVMdRBNTvXWuhzercPv6o0rnAUQsifjSkVnU7KysJPti7i5kXfpVr6BOqOUuFLUqO6c8VG9Bx0lP0-x2ZtYtSDdyg81AfDZ6MvcIlcehX0HjRq7i-nIg__",
    capacity: 600,
    amenities: ["parking", "catering", "decoration", "sound"],
    description:
      "Historic palace venue with traditional Rajasthani architecture and royal ambiance. Experience the grandeur of Rajasthan's royal heritage with this magnificent palace venue featuring intricate architecture, beautiful gardens, and authentic cultural experiences.",
    discount: 0,
    trending: true,
  },
  {
    id: "6",
    name: "Lakeside Retreat",
    location: "Udaipur, Rajasthan",
    price: 45000,
    rating: 4.8,
    image:
      "https://media-hosting.imagekit.io//2a74a819d5214c30/8.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=jlGPCskrcd~O8WYJK~iZXk2WSWhy4ifbvJObEn-ROP8BBLrzRTMy3RVExGtwPyJuASJfgDoIz6YY2A659jDQNtIaOWWcZv2HcmQRCH6NIewJ7v-K0I~vT~ikROa5F2q2kl4b2JpH49AsshHTJdI-fpNmaqoYNoyylFzTg2taCjZIsle0Jzi5wwLXuramx5Eu3eVBtUcDI64FytbBowv0EMuyoEu4Tk39PxfvAJW8iEvIiY~rZjqtyiJjawXJzq~Y8cwr5fQBy4kp28Joj16n~FDiYGPik426Vo1EgVEBTutJxtKmaK6pLLi2ZYJtWAzTI1oHYaW6FF-07QZ1CQJI8Q__",
    capacity: 350,
    amenities: ["parking", "catering", "decoration"],
    description:
      "Serene lakeside venue with water views and peaceful surroundings. Set on the banks of Lake Pichola, this tranquil venue offers romantic settings, boat access, and stunning views of the historic city palaces across the water.",
    discount: 12,
  },
  {
    id: "7",
    name: "Green Valley Farm",
    location: "Pune, Maharashtra",
    price: 20000,
    rating: 4.5,
    image:
      "https://media-hosting.imagekit.io//0da8110e9da34ba8/9.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=yT7KHpqn4VdoLChPX6UDPEGj6k~PWYUF~omEzkyJ~2I7yfBwZpg2-jguPIE9iEkybUp1uvI050a46ObNQgQX8YB7rxLWz-7F0eMNVBMV~xs1GKtyjPEBSyyIYeQBAat~f7ukkKGVbODX5wH5kgP1mXMIUCUg67zkxLHmrg2dM385mnpvEJbTaD0TD7FBRfGpHymeseuqmI5lMI3zcCI7S2GqRbxvDNPXYDFgnKiDHSIl63lBHVu2pTA-9VkbfY0H0oX4-KfVM6GpHo8VkR44qyzlowpvY5eIZ4BjI88LArSTGcaZ72O2FUQlcjDHowHtaaFyb3O7gaoId6EG~NjNcA__",
    capacity: 450,
    amenities: ["parking", "catering", "sound"],
    description:
      "Spacious farmhouse with lush green surroundings and outdoor spaces. This rustic venue offers a refreshing escape from the city with its sprawling lawns, organic farm, and versatile event spaces suitable for both intimate gatherings and large celebrations.",
    discount: 20,
  },
  {
    id: "8",
    name: "Starlight Convention Center",
    location: "Bangalore, Karnataka",
    price: 35000,
    rating: 4.7,
    image:
      "https://media-hosting.imagekit.io//173f3dc8ff5146b3/5.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=xt2QE3cDLye4uyov4wmVy6XkCfQfZZ9LvynaWZg0nO-gq9UiBOvKD9w-1uEhGJ3FWxbigNu3zM4jTIxweCKy~4KcH6ZVDeRA-UweV~5bQe~6fxX5X5Zi~nqnJx66e9ObCTRhWm9epMJUowObN9sfZr3mlhd56wrFyRjiwxzZiIbQocB6iv2lEqmEQbwwHqdqixsobJKcZqQQC82WZAtvXceP-oe~93YGwxY8B6ULzZ9RPklVQwRmyW3PYBAQaJ-sRbj32ryyZnpqxaCC4c3ykHBOJDzKUApgD0eZ4kS8esFr0k9SrPm7UNAXCWNrONxl3AqU8Wa97DLfZNIBc2QYTg__",
    capacity: 800,
    amenities: ["parking", "catering", "decoration", "sound"],
    description:
      "Modern convention center with state-of-the-art facilities and elegant decor. This premium venue in Bangalore's tech hub features cutting-edge audiovisual equipment, flexible spaces, and professional event management for corporate events and large celebrations.",
    discount: 8,
  },
  {
    id: "9",
    name: "Riverside Pavilion",
    location: "Varanasi, Uttar Pradesh",
    price: 28000,
    rating: 4.6,
    image:
      "https://media-hosting.imagekit.io//4bab4570e3554742/4.jpeg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=FtGF8TwMNjvvOm~y57a3REzV8H8vNq6w61g8MdCu4KYsGJe13ZRJspWgrxA5kocvplrH-gacdssSsmiKiLNSFDAzZ-FVX5wTkj~BUae2CIi1MdxSvRg66EvPsfrkBTlvexfyJkg0NgEJ~SIU44wErH1e3gYgJ0jqXMGTNIeHH3~HkiNepg9AaVLvaUL85x1d4ViQNMT83oK0YTNjB45WbeaymD-v3vuF0WjFj7BiF9MfYpU8WInPT8EPh1bWvJpSVca5gNJU8j1nbU3d9tp-Us5x6ytI3WmhIRK0vVDi5DkbyszFYDA53V6YsRTlDT5bB8RGb9Xu6vPEAH9k7kzfvg__",
    capacity: 300,
    amenities: ["parking", "catering", "decoration"],
    description:
      "Scenic venue by the river with traditional architecture and spiritual ambiance. Located on the banks of the sacred Ganges, this venue offers a unique cultural experience with its ghats, ancient architecture, and spiritual significance.",
    discount: 0,
  },
  {
    id: "10",
    name: "Tropical Paradise Resort",
    location: "Kochi, Kerala",
    price: 32000,
    rating: 4.8,
    image:
      "https://media-hosting.imagekit.io//806ab725979d4f97/3.jpg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=QMF6Y8jzyhETDN0~-wms62EoHw9AbBgFV-wHPxdD3pXcKghpF4Dyvsz~3hIADYHhrSs5y5ZXOgnY-3f-mwUkTqMS-uK8vWTd~rIiquLke04v99abBZJixUBnWP5nJ37HzLMQpEb6IdA2KrazPQorV9jg1LGGG3TOuV0ERjsDm4ykP3lh1qTC4qoGWDXxQI8XEHEUb~BhHIVOBNo3kkYP35EFqustS8U0AV6ZfyZd4RftHDkLUaKVNxNjWZV066l1bnLGfFquvjb73sybncN2dXtXwPOgL74eYw5TXzEfEewyD~pVfjAroF92r1shevBcxdR-RRB7ebGeQBUISJORLw__",
    capacity: 400,
    amenities: ["parking", "catering", "decoration", "sound"],
    description:
      "Tropical-themed resort with lush gardens and backwater views. Experience Kerala's famous backwaters at this beautiful resort featuring traditional architecture, coconut groves, and authentic Kerala cuisine for a memorable destination wedding or event.",
    discount: 15,
  },
  {
    id: "11",
    name: "Grand Ballroom",
    location: "Chennai, Tamil Nadu",
    price: 38000,
    rating: 4.7,
    image:
      "https://media-hosting.imagekit.io//bb929a9a15dc44af/1.jpg?Expires=1836277556&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=fbICwzVbZQqHxI2wmI9QNSr89~K1eQPrkFW98nsx3rzvmyWpPjc0Q-Q5KR6xBB1Y0Y5-JiWr5VjtRjzo8s9D1pDVwwL40vIvimprOEo2DuYxmWQO4yjJ861OCVHJghN7~0ox5OF6zI62uCmb8mJTj7-ATKHaFCoUrfhsxoleMPLkK8PFmSZL3W9KLa6NgziTmQKI2hjdKd1ieNbcCJfPjjpNyx08hrSCEuHPe5Kwd32Ex9-P6xyxInbMYCd0lYvEbjt5w5kayruKK92wxmUpq5R51UAN4vYAJX429teICFDk3XyQZ43CjBBd5mzxSafWa8S4BvE5wL8yhfGKpNVL1Q__",
    capacity: 550,
    amenities: ["parking", "catering", "decoration", "sound"],
    description:
      "Elegant ballroom with crystal chandeliers and sophisticated ambiance. This opulent venue features marble floors, grand pillars, and luxurious decor perfect for high-end weddings, galas, and corporate events requiring a touch of elegance.",
    discount: 0,
  },
  {
    id: "12",
    name: "Hillside Meadows",
    location: "Ooty, Tamil Nadu",
    price: 30000,
    rating: 4.5,
    image:
      "https://media-hosting.imagekit.io//d4d070f21eed40fe/2.jpg?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=MDyUN8WrANpLZikCc1AWbWuubpj4SOgfPZkOLfft35X~rOBUXWhieaCocwkMPYBWH~s87jqHNDcpW1BO8Ah4~cGg2EEQzB9wZxkHw2y7m-e17pLho1AJ~Jh5FagFDl-Cpeio8FLNh2t2h44QPSIMEybnV5HO8aBL759X5ISJLZXP7vlpyq-1YBenADwJt8GSrv4ocY-XVSC8hv30qYv6g0JBvb3ml3gWUyUvyu4vhUi06E1roCpQ56UL5ybGh5PgNBtmYqUzwes4Pe7BlEcAihrNI6AhN8LSsLe-yHtRVUEjoqrOwVymYF-7Hl-xey~uy2vfKuJn0~Fb13FnyHxKDQ__",
    capacity: 250,
    amenities: ["parking", "catering"],
    description:
      "Picturesque hillside venue with meadows and cool climate. Nestled in the Nilgiri Hills, this charming venue offers misty mountain views, flower gardens, and a pleasant climate year-round, making it ideal for outdoor events and intimate celebrations.",
    discount: 10,
  },
]

