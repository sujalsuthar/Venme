"use client"

import type React from "react"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Star, MapPin, Heart, ShoppingCart, Share2, ArrowRight } from "lucide-react"
import { useFavorites } from "@/lib/providers/favorites-provider"
import { useCart } from "@/lib/hooks/use-cart"
import { useState } from "react"
import BookingModal from "./booking-modal"
import type { Listing } from "@/lib/types"
import { useRecentlyViewed } from "@/lib/hooks/use-recently-viewed"
import { useRouter } from "next/navigation"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

interface ListingCardProps {
  listing: Listing
  showActions?: boolean
  index?: number
}

export default function ListingCard({ listing, showActions = true, index = 0 }: ListingCardProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { addToFavorites, isInFavorites, removeFromFavorites } = useFavorites()
  const { addToCart, isInCart } = useCart()
  const { addToRecentlyViewed } = useRecentlyViewed()
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleFavoritesToggle = (e: React.MouseEvent) => {
    e.stopPropagation() // Prevent navigation when clicking the favorites button
    if (isInFavorites(listing.id)) {
      removeFromFavorites(listing.id)
      toast({
        title: "Removed from favorites",
        description: `${listing.name} has been removed from your favorites.`,
      })
    } else {
      addToFavorites(listing)
      toast({
        title: "Added to favorites",
        description: `${listing.name} has been added to your favorites.`,
      })
    }
  }

  const handleBookNow = (e: React.MouseEvent) => {
    e.stopPropagation() // Prevent navigation when clicking the book now button
    setIsBookingModalOpen(true)
  }

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation() // Prevent navigation when clicking the add to cart button
    if (!isInCart(listing.id)) {
      setIsLoading(true)
      // Simulate network request
      setTimeout(() => {
        addToCart(listing)
        setIsLoading(false)
        toast({
          title: "Added to cart",
          description: `${listing.name} has been added to your cart.`,
        })
      }, 800)
    } else {
      router.push("/cart")
    }
  }

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation() // Prevent navigation when clicking the share button
    if (navigator.share) {
      navigator
        .share({
          title: listing.name,
          text: `Check out this amazing venue: ${listing.name}`,
          url: window.location.href,
        })
        .catch((err) => {
          console.error("Error sharing:", err)
        })
    } else {
      // Fallback for browsers that don't support navigator.share
      navigator.clipboard.writeText(window.location.href)
      toast({
        title: "Link copied",
        description: "The link has been copied to your clipboard.",
      })
    }
  }

  const handleViewDetails = () => {
    addToRecentlyViewed(listing)
    router.push(`/listings/${listing.id}`)
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: index * 0.1 }}
        whileHover={{ y: -8 }}
        className="bg-card rounded-lg shadow-lg overflow-hidden cursor-pointer border border-border hover:border-accent"
        onClick={handleViewDetails}
      >
        <div className="relative h-48 overflow-hidden">
          <Image
            src={listing.image || "/placeholder.svg"}
            alt={listing.name}
            fill
            className="object-cover transition-transform duration-500 hover:scale-110"
          />
          {listing.discount > 0 && (
            <Badge className="absolute top-2 left-2 bg-accent text-accent-foreground animate-pulse">
              {listing.discount}% OFF
            </Badge>
          )}
          {listing.trending && <Badge className="absolute top-2 right-2 bg-[#FFD700] text-black">Trending</Badge>}
        </div>
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-semibold text-card-foreground hover:text-accent transition-colors duration-200">
              {listing.name}
            </h3>
            <div className="flex items-center bg-[#FFD700] px-2 py-1 rounded text-sm">
              <Star className="h-4 w-4 mr-1 fill-current" />
              {listing.rating}
            </div>
          </div>
          <p className="flex items-center text-muted-foreground mb-2">
            <MapPin className="h-4 w-4 mr-1" />
            {listing.location}
          </p>
          <div className="flex items-baseline mb-4">
            <p className="text-lg font-bold text-card-foreground">
              ₹{(listing.price * (1 - listing.discount / 100)).toLocaleString()}
            </p>
            {listing.discount > 0 && (
              <p className="text-sm text-muted-foreground line-through ml-2">₹{listing.price.toLocaleString()}</p>
            )}
          </div>

          {showActions && (
            <div className="flex space-x-2" onClick={(e) => e.stopPropagation()}>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex-1">
                <Button onClick={handleBookNow} className="w-full bg-[#0A2647] hover:bg-[#0A2647]/90">
                  Book Now
                </Button>
              </motion.div>

              <div className="flex space-x-1">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <motion.div whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={handleFavoritesToggle}
                          className={cn(
                            "border-border hover:border-accent transition-all duration-200",
                            isInFavorites(listing.id) && "bg-accent/10 border-accent text-accent",
                          )}
                        >
                          <Heart
                            className={cn(
                              "h-4 w-4 transition-all duration-200",
                              isInFavorites(listing.id) && "fill-accent animate-pulse",
                            )}
                          />
                        </Button>
                      </motion.div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isInFavorites(listing.id) ? "Remove from Favorites" : "Add to Favorites"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <motion.div whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={handleAddToCart}
                          disabled={isLoading}
                          className={cn(
                            "border-border hover:border-accent transition-all duration-200",
                            isInCart(listing.id) && "bg-primary/10 border-primary text-primary",
                          )}
                        >
                          {isLoading ? (
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-accent border-t-transparent" />
                          ) : (
                            <ShoppingCart
                              className={cn(
                                "h-4 w-4 transition-all duration-200",
                                isInCart(listing.id) && "fill-primary",
                              )}
                            />
                          )}
                        </Button>
                      </motion.div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{isInCart(listing.id) ? "Go to Cart" : "Add to Cart"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <motion.div whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={handleShare}
                          className="border-border hover:border-accent transition-all duration-200"
                        >
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </motion.div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Share</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </div>
          )}

          {!showActions && (
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                className="w-full justify-between border-accent text-accent hover:bg-accent/10 mt-2"
                onClick={(e) => {
                  e.stopPropagation()
                  handleViewDetails()
                }}
              >
                View Details
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </motion.div>
          )}
        </div>
      </motion.div>

      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        onConfirm={() => {
          addToCart(listing)
          setIsBookingModalOpen(false)
          toast({
            title: "Added to Cart",
            description: `${listing.name} has been added to your cart.`,
          })
        }}
        listings={[listing]}
      />
    </>
  )
}

