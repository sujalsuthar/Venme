"use client"

import { useRef } from "react"
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star } from "lucide-react"
import { motion, useInView } from "framer-motion"

export default function Testimonials() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const testimonials = [
    {
      id: 1,
      name: "Priya Sharma",
      role: "Bride",
      avatar: "/placeholder.svg?height=100&width=100",
      content:
        "We booked Royal Garden for our wedding and it was absolutely perfect! The staff was very helpful and the venue looked stunning.",
      rating: 5,
    },
    {
      id: 2,
      name: "Rahul Mehta",
      role: "Event Manager",
      avatar: "/placeholder.svg?height=100&width=100",
      content:
        "As an event manager, I've worked with many venues, but the service at City Lights Banquet is exceptional. Highly recommended!",
      rating: 4,
    },
    {
      id: 3,
      name: "Ananya Patel",
      role: "Corporate Client",
      avatar: "/placeholder.svg?height=100&width=100",
      content:
        "We organized our annual company retreat at Mountain View Resort. The amenities were top-notch and our team loved it.",
      rating: 5,
    },
    {
      id: 4,
      name: "Vikram Singh",
      role: "Birthday Celebration",
      avatar: "/placeholder.svg?height=100&width=100",
      content:
        "Booked Sunset Beach Venue for my 50th birthday. The beachfront setting created the perfect atmosphere for our celebration.",
      rating: 4,
    },
  ]

  return (
    <div ref={ref} className="my-16">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: isInView ? 1 : 0 }} transition={{ duration: 0.5 }}>
        <motion.h2
          className="text-3xl font-bold mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          What Our Customers Say
        </motion.h2>

        <Carousel className="w-full">
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem key={testimonial.id} className="md:basis-1/2 lg:basis-1/3 p-1">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 20 }}
                  transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                  whileHover={{ y: -5 }}
                  className="h-full"
                >
                  <Card className="h-full">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-4">
                        <Avatar className="h-10 w-10 mr-4">
                          <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                          <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{testimonial.name}</p>
                          <p className="text-sm text-gray-500">{testimonial.role}</p>
                        </div>
                      </div>

                      <div className="flex mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < testimonial.rating ? "text-[#FFD700] fill-[#FFD700]" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>

                      <p className="text-gray-700">{testimonial.content}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <CarouselPrevious className="left-2" />
          </motion.div>
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <CarouselNext className="right-2" />
          </motion.div>
        </Carousel>
      </motion.div>
    </div>
  )
}

