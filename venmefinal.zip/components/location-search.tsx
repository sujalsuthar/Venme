"use client"

import { useState, useEffect, useRef } from "react"
import { Input } from "@/components/ui/input"
import { MapPin } from "lucide-react"

interface LocationSearchProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}

declare global {
  interface Window {
    google: any
  }
}

export default function LocationSearch({ value, onChange, placeholder = "Location" }: LocationSearchProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const autocompleteRef = useRef<any>(null)
  const [scriptLoaded, setScriptLoaded] = useState(false)

  // Load Google Places API script
  useEffect(() => {
    if (!scriptLoaded && !window.google) {
      const script = document.createElement("script")
      script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places`
      script.async = true
      script.defer = true
      script.onload = () => setScriptLoaded(true)
      document.head.appendChild(script)
      return () => {
        document.head.removeChild(script)
      }
    } else if (window.google) {
      setScriptLoaded(true)
    }
  }, [scriptLoaded])

  // Initialize autocomplete
  useEffect(() => {
    if (scriptLoaded && inputRef.current) {
      autocompleteRef.current = new window.google.maps.places.Autocomplete(inputRef.current, {
        types: ["(cities)"],
        componentRestrictions: { country: "in" }, // Restrict to India
      })

      autocompleteRef.current.addListener("place_changed", () => {
        const place = autocompleteRef.current.getPlace()
        if (place && place.formatted_address) {
          onChange(place.formatted_address)
        }
      })
    }
  }, [scriptLoaded, onChange])

  return (
    <div className="relative">
      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
      <Input
        ref={inputRef}
        placeholder={placeholder}
        className="pl-10"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  )
}

