"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import ListingCard from "./listing-card"
import { listings } from "@/lib/data"
import { useRouter } from "next/navigation"
import { motion, useInView } from "framer-motion"

export default function FeaturedListings() {
  const router = useRouter()
  const [currentIndex, setCurrentIndex] = useState(0)
  const featuredListings = listings.filter((listing) => listing.trending)
  const visibleListings = 3
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const handlePrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex > 0 ? prevIndex - 1 : 0))
  }

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex < featuredListings.length - visibleListings ? prevIndex + 1 : prevIndex))
  }

  const handleViewAll = () => {
    router.push("/listings")
  }

  return (
    <section ref={ref} className="py-12 bg-background">
      <motion.div
        className="container mx-auto px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: isInView ? 1 : 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div
          className="flex justify-between items-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h2 className="text-2xl font-bold text-foreground">Featured Venues</h2>
          <div className="flex items-center space-x-2">
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button
                variant="outline"
                size="icon"
                onClick={handlePrevious}
                disabled={currentIndex === 0}
                className="rounded-full border-accent text-accent hover:bg-accent/10 transition-all duration-200"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button
                variant="outline"
                size="icon"
                onClick={handleNext}
                disabled={currentIndex >= featuredListings.length - visibleListings}
                className="rounded-full border-accent text-accent hover:bg-accent/10 transition-all duration-200"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </motion.div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredListings.slice(currentIndex, currentIndex + visibleListings).map((listing, index) => (
            <ListingCard key={listing.id} listing={listing} index={index} />
          ))}
        </div>

        <motion.div
          className="flex justify-center mt-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 20 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button onClick={handleViewAll} className="bg-[#0A2647] hover:bg-[#0A2647]/90">
              View All Listings
            </Button>
          </motion.div>
        </motion.div>
      </motion.div>
    </section>
  )
}

