"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, Calendar, MapPin, Users, Download, Share2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import type { Listing } from "@/lib/types"

interface BookingConfirmationProps {
  booking: {
    id: string
    date: string
    listing: Listing
    totalAmount: number
    paymentMethod: string
  }
  onClose: () => void
}

export default function BookingConfirmation({ booking, onClose }: BookingConfirmationProps) {
  const { toast } = useToast()
  const router = useRouter()
  const [isSharingInvite, setIsSharingInvite] = useState(false)

  const handleDownloadInvoice = () => {
    toast({
      title: "Invoice Downloaded",
      description: "Your invoice has been downloaded successfully.",
    })
    // In a real app, this would generate and download a PDF
  }

  const handleShareInvite = async () => {
    setIsSharingInvite(true)

    try {
      if (navigator.share) {
        await navigator.share({
          title: `Invitation to event at ${booking.listing.name}`,
          text: `I've booked ${booking.listing.name} for an event on ${new Date(booking.date).toLocaleDateString()}. Hope you can join!`,
          url: window.location.origin,
        })
      } else {
        // Fallback for browsers that don't support navigator.share
        await navigator.clipboard.writeText(
          `I've booked ${booking.listing.name} for an event on ${new Date(booking.date).toLocaleDateString()}. Hope you can join!`,
        )
        toast({
          title: "Invite Link Copied",
          description: "The invitation link has been copied to your clipboard.",
        })
      }
    } catch (error) {
      console.error("Error sharing:", error)
    } finally {
      setIsSharingInvite(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="bg-[#0A2647] text-white rounded-t-lg">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-white rounded-full p-2">
              <Check className="h-8 w-8 text-[#0A2647]" />
            </div>
          </div>
          <CardTitle className="text-center">Booking Confirmed!</CardTitle>
          <CardDescription className="text-white/80 text-center">
            Your booking has been confirmed. Check your email for details.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-semibold text-lg mb-2">{booking.listing.name}</h3>
              <div className="space-y-2 text-gray-600">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>
                    {new Date(booking.date).toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>{booking.listing.location}</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-2" />
                  <span>Capacity: {booking.listing.capacity} guests</span>
                </div>
              </div>
            </div>

            <div className="border-t border-b py-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Booking ID</span>
                <span className="font-medium">{booking.id}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Payment Method</span>
                <span className="font-medium">{booking.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total Amount</span>
                <span className="font-bold">₹{booking.totalAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-3">
          <div className="flex space-x-3 w-full">
            <Button variant="outline" className="flex-1" onClick={handleDownloadInvoice}>
              <Download className="h-4 w-4 mr-2" />
              Invoice
            </Button>
            <Button variant="outline" className="flex-1" onClick={handleShareInvite} disabled={isSharingInvite}>
              <Share2 className="h-4 w-4 mr-2" />
              Share Invite
            </Button>
          </div>
          <Button className="w-full bg-[#0A2647] hover:bg-[#0A2647]/90" onClick={onClose}>
            View My Bookings
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

