"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"

interface OtpVerificationProps {
  email: string
  phone?: string
  onVerified: () => void
  onCancel: () => void
}

export default function OtpVerification({ email, phone, onVerified, onCancel }: OtpVerificationProps) {
  const { toast } = useToast()
  const [otp, setOtp] = useState(["", "", "", "", "", ""])
  const [timer, setTimer] = useState(30)
  const [isResending, setIsResending] = useState(false)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  // Generate a random OTP for demo purposes
  const [generatedOtp] = useState(() => {
    return Array.from({ length: 6 }, () => Math.floor(Math.random() * 10).toString())
  })

  useEffect(() => {
    // Show the generated OTP in a toast for demo purposes
    toast({
      title: "OTP Generated",
      description: `Your OTP is ${generatedOtp.join("")}. Use this to verify.`,
    })

    // Start the countdown timer
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [generatedOtp, toast])

  const handleInputChange = (index: number, value: string) => {
    if (value.length > 1) {
      value = value.charAt(0)
    }

    if (value && !/^\d+$/.test(value)) {
      return
    }

    const newOtp = [...otp]
    newOtp[index] = value
    setOtp(newOtp)

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  const handleVerify = () => {
    const enteredOtp = otp.join("")
    const correctOtp = generatedOtp.join("")

    if (enteredOtp === correctOtp) {
      toast({
        title: "Verification Successful",
        description: "Your OTP has been verified successfully.",
      })
      onVerified()
    } else {
      toast({
        title: "Verification Failed",
        description: "The OTP you entered is incorrect. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleResendOtp = () => {
    setIsResending(true)

    // Simulate API call to resend OTP
    setTimeout(() => {
      // Generate a new OTP
      const newOtp = Array.from({ length: 6 }, () => Math.floor(Math.random() * 10).toString())

      toast({
        title: "OTP Resent",
        description: `Your new OTP is ${newOtp.join("")}. Use this to verify.`,
      })

      setTimer(30)
      setIsResending(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>OTP Verification</CardTitle>
          <CardDescription>
            We've sent a verification code to {email}
            {phone ? ` and ${phone}` : ""}. Please enter the code below.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center gap-2 mb-6">
            {otp.map((digit, index) => (
              <Input
                key={index}
                ref={(el) => (inputRefs.current[index] = el)}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleInputChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-12 text-center text-lg"
                autoFocus={index === 0}
              />
            ))}
          </div>

          <div className="text-center text-sm text-muted-foreground">
            {timer > 0 ? (
              <p>Resend code in {timer} seconds</p>
            ) : (
              <Button variant="link" onClick={handleResendOtp} disabled={isResending} className="p-0 h-auto">
                {isResending ? "Resending..." : "Resend code"}
              </Button>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button onClick={handleVerify} disabled={otp.some((digit) => !digit)}>
            Verify
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

