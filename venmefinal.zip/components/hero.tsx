"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Users, DollarSign } from "lucide-react"
import LocationSearch from "./location-search"
import { motion } from "framer-motion"

export default function Hero() {
  const router = useRouter()
  const [location, setLocation] = useState("")
  const [capacity, setCapacity] = useState("")
  const [priceRange, setPriceRange] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()

    // Build query params
    const params = new URLSearchParams()
    if (location) params.append("location", location)
    if (capacity) params.append("capacity", capacity)
    if (priceRange) params.append("price", priceRange)

    router.push(`/listings?${params.toString()}`)
  }

  return (
    <div className="relative h-[80vh] flex items-center">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: "url('/placeholder.svg?height=1080&width=1920')",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50">
          {/* Animated particles */}
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 rounded-full bg-white/30"
              initial={{
                x: Math.random() * 100 + "%",
                y: Math.random() * 100 + "%",
                opacity: Math.random() * 0.5 + 0.3,
              }}
              animate={{
                y: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
              }}
              transition={{
                duration: Math.random() * 10 + 10,
                repeat: Number.POSITIVE_INFINITY,
                repeatType: "reverse",
              }}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <motion.div
        className="container mx-auto px-4 relative z-10 text-white"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-3xl">
          <motion.h1
            className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Find the Perfect Venue for Your Special Occasion
          </motion.h1>
          <motion.p
            className="text-xl mb-8 opacity-90"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            Discover and book the best party plots for weddings, corporate events, and celebrations
          </motion.p>

          {/* Search Form */}
          <motion.form
            onSubmit={handleSearch}
            className="bg-white/10 backdrop-blur-md p-4 rounded-lg shadow-lg text-black"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <LocationSearch value={location} onChange={setLocation} placeholder="Location" />
              </div>

              <div className="relative">
                <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Select value={capacity} onValueChange={setCapacity}>
                  <SelectTrigger className="pl-10 bg-white/80 backdrop-blur-sm">
                    <SelectValue placeholder="Capacity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="100">100+ Guests</SelectItem>
                    <SelectItem value="200">200+ Guests</SelectItem>
                    <SelectItem value="500">500+ Guests</SelectItem>
                    <SelectItem value="1000">1000+ Guests</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Select value={priceRange} onValueChange={setPriceRange}>
                  <SelectTrigger className="pl-10 bg-white/80 backdrop-blur-sm">
                    <SelectValue placeholder="Price Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10000">Under ₹10,000</SelectItem>
                    <SelectItem value="25000">Under ₹25,000</SelectItem>
                    <SelectItem value="50000">Under ₹50,000</SelectItem>
                    <SelectItem value="100000">Under ₹100,000</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  type="submit"
                  className="w-full bg-[#0A2647] hover:bg-[#0A2647]/90 relative overflow-hidden group"
                >
                  <span className="relative z-10 flex items-center">
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </span>
                </Button>
              </motion.div>
            </div>
          </motion.form>
        </div>
      </motion.div>

      {/* Animated scroll indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
      >
        <div className="w-8 h-12 rounded-full border-2 border-white/50 flex justify-center pt-2">
          <motion.div
            className="w-1 h-2 bg-white rounded-full"
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
          />
        </div>
      </motion.div>
    </div>
  )
}

