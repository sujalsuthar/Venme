"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"
import {
  BarChart,
  Bell,
  Building,
  Calendar,
  CreditCard,
  LogOut,
  Menu,
  MessageSquare,
  Settings,
  User,
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface OwnerLayoutProps {
  children: React.ReactNode
}

export default function OwnerLayout({ children }: OwnerLayoutProps) {
  const router = useRouter()
  const pathname = usePathname()
  const { owner, logout } = useOwnerAuth()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  const navItems = [
    {
      name: "Dashboard",
      href: "/owner/dashboard",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      name: "Listings",
      href: "/owner/listings",
      icon: <Building className="h-5 w-5" />,
    },
    {
      name: "Bookings",
      href: "/owner/bookings",
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      name: "Negotiation Requests",
      href: "/owner/negotiation-requests",
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      name: "Payments",
      href: "/owner/payments",
      icon: <CreditCard className="h-5 w-5" />,
    },
    {
      name: "Profile",
      href: "/owner/profile",
      icon: <User className="h-5 w-5" />,
    },
    {
      name: "Settings",
      href: "/owner/settings",
      icon: <Settings className="h-5 w-5" />,
    },
  ]

  const handleLogout = () => {
    logout()
    router.push("/owner/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <header className="bg-white border-b sticky top-0 z-30">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center">
              {/* Mobile menu button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-64">
                  <div className="flex flex-col h-full">
                    <div className="py-4 border-b">
                      <Link href="/owner/dashboard" className="text-2xl font-bold text-[#0A2647]">
                        PartyPlot
                      </Link>
                      <p className="text-sm text-gray-500">Owner Portal</p>
                    </div>
                    <nav className="flex-1 py-4">
                      <ul className="space-y-1">
                        {navItems.map((item) => (
                          <li key={item.href}>
                            <Link
                              href={item.href}
                              className={`flex items-center px-3 py-2 rounded-md text-sm ${
                                pathname === item.href ? "bg-[#0A2647] text-white" : "text-gray-700 hover:bg-gray-100"
                              }`}
                            >
                              <span className="mr-3">{item.icon}</span>
                              {item.name}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </nav>
                    <div className="py-4 border-t">
                      <Button
                        variant="ghost"
                        className="w-full justify-start text-red-600 hover:bg-red-50 hover:text-red-700"
                        onClick={handleLogout}
                      >
                        <LogOut className="h-5 w-5 mr-3" />
                        Logout
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>

              {/* Logo */}
              <Link href="/owner/dashboard" className="text-2xl font-bold text-[#0A2647] hidden md:block">
                PartyPlot
              </Link>
            </div>

            <div className="flex items-center gap-4">
              {/* Notifications */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="h-5 w-5" />
                    <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-500">
                      3
                    </Badge>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <div className="max-h-80 overflow-y-auto">
                    <DropdownMenuItem className="flex flex-col items-start py-3">
                      <div className="flex items-center w-full">
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                          <Calendar className="h-4 w-4 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">New Booking Request</p>
                          <p className="text-sm text-gray-500">Royal Garden Party Plot</p>
                        </div>
                        <p className="text-xs text-gray-400">5m ago</p>
                      </div>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="flex flex-col items-start py-3">
                      <div className="flex items-center w-full">
                        <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                          <CreditCard className="h-4 w-4 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Payment Received</p>
                          <p className="text-sm text-gray-500">₹25,000 for Sunset Beach Venue</p>
                        </div>
                        <p className="text-xs text-gray-400">2h ago</p>
                      </div>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="flex flex-col items-start py-3">
                      <div className="flex items-center w-full">
                        <div className="h-8 w-8 rounded-full bg-amber-100 flex items-center justify-center mr-3">
                          <User className="h-4 w-4 text-amber-600" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">New Review</p>
                          <p className="text-sm text-gray-500">4★ review for Mountain View Resort</p>
                        </div>
                        <p className="text-xs text-gray-400">1d ago</p>
                      </div>
                    </DropdownMenuItem>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-center text-sm text-blue-600 cursor-pointer">
                    View all notifications
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* User menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar>
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt={owner?.name || "User"} />
                      <AvatarFallback>{owner?.name?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => router.push("/owner/profile")}>
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => router.push("/owner/settings")}>
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex">
        {/* Sidebar (desktop only) */}
        <aside className="hidden md:block w-64 bg-white border-r h-[calc(100vh-4rem)] sticky top-16">
          <nav className="p-4">
            <ul className="space-y-1">
              {navItems.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={`flex items-center px-3 py-2 rounded-md ${
                      pathname === item.href ? "bg-[#0A2647] text-white" : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    <span className="mr-3">{item.icon}</span>
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Content */}
        <main className="flex-1 p-6">
          <div className="container mx-auto">{children}</div>
        </main>
      </div>
    </div>
  )
}

