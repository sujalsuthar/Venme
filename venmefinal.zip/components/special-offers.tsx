"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, ArrowRight } from "lucide-react"
import { listings } from "@/lib/data"
import { useRouter } from "next/navigation"
import { useRecentlyViewed } from "@/lib/hooks/use-recently-viewed"
import { motion, useInView } from "framer-motion"

export default function SpecialOffers() {
  const router = useRouter()
  const { addToRecentlyViewed } = useRecentlyViewed()
  const [timeLeft, setTimeLeft] = useState({
    days: 2,
    hours: 23,
    minutes: 59,
    seconds: 59,
  })
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  // Get listings with discounts, sorted by discount percentage (highest first)
  const discountedListings = listings
    .filter((listing) => listing.discount > 0)
    .sort((a, b) => b.discount - a.discount)
    .slice(0, 1)

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        const newSeconds = prev.seconds - 1
        if (newSeconds >= 0) return { ...prev, seconds: newSeconds }

        const newMinutes = prev.minutes - 1
        if (newMinutes >= 0) return { ...prev, minutes: newMinutes, seconds: 59 }

        const newHours = prev.hours - 1
        if (newHours >= 0) return { ...prev, hours: newHours, minutes: 59, seconds: 59 }

        const newDays = prev.days - 1
        if (newDays >= 0) return { days: newDays, hours: 23, minutes: 59, seconds: 59 }

        // If timer reaches zero, reset it
        return { days: 2, hours: 23, minutes: 59, seconds: 59 }
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  if (discountedListings.length === 0) {
    return null
  }

  const listing = discountedListings[0]

  const handleViewOffer = () => {
    addToRecentlyViewed(listing)
    router.push(`/listings/${listing.id}`)
  }

  return (
    <section ref={ref} className="py-12 bg-gradient-to-r from-[#0A2647] to-[#144272] text-white">
      <motion.div
        className="container mx-auto px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: isInView ? 1 : 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col lg:flex-row items-center gap-8">
          <motion.div
            className="lg:w-1/2 relative h-[300px] lg:h-[400px] w-full rounded-lg overflow-hidden"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: isInView ? 1 : 0, x: isInView ? 0 : -50 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Image src={listing.image || "/placeholder.svg"} alt={listing.name} fill className="object-cover" />
            <Badge className="absolute top-4 left-4 bg-[#FF6B6B] text-lg py-1 px-3">{listing.discount}% OFF</Badge>
          </motion.div>

          <motion.div
            className="lg:w-1/2 space-y-6"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: isInView ? 1 : 0, x: isInView ? 0 : 50 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <div>
              <h2 className="text-3xl font-bold mb-2">Special Offer</h2>
              <p className="text-gray-300">Limited time discount on premium venues</p>
            </div>

            <h3 className="text-2xl font-semibold">{listing.name}</h3>
            <p className="text-gray-300">{listing.description.substring(0, 150)}...</p>

            <div className="flex items-baseline space-x-3">
              <span className="text-3xl font-bold">
                ₹{(listing.price * (1 - listing.discount / 100)).toLocaleString()}
              </span>
              <span className="text-xl text-gray-300 line-through">₹{listing.price.toLocaleString()}</span>
              <Badge className="bg-green-500">
                Save ₹{((listing.price * listing.discount) / 100).toLocaleString()}
              </Badge>
            </div>

            <div className="bg-[#205295]/50 p-4 rounded-lg">
              <div className="flex items-center mb-2">
                <Clock className="h-5 w-5 mr-2" />
                <span>Offer ends in:</span>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center">
                <div className="bg-[#0A2647] p-2 rounded">
                  <div className="text-2xl font-bold">{timeLeft.days}</div>
                  <div className="text-xs text-gray-300">Days</div>
                </div>
                <div className="bg-[#0A2647] p-2 rounded">
                  <div className="text-2xl font-bold">{timeLeft.hours}</div>
                  <div className="text-xs text-gray-300">Hours</div>
                </div>
                <div className="bg-[#0A2647] p-2 rounded">
                  <div className="text-2xl font-bold">{timeLeft.minutes}</div>
                  <div className="text-xs text-gray-300">Minutes</div>
                </div>
                <div className="bg-[#0A2647] p-2 rounded">
                  <div className="text-2xl font-bold">{timeLeft.seconds}</div>
                  <div className="text-xs text-gray-300">Seconds</div>
                </div>
              </div>
            </div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button onClick={handleViewOffer} className="w-full bg-[#FF6B6B] hover:bg-[#FF6B6B]/90 text-white">
                View Offer
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  )
}

