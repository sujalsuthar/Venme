"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { usePathname } from "next/navigation"
import { Menu, Heart, ShoppingCart, Calendar, Search, Home, LogIn, User, Moon, Sun } from "lucide-react"
import { useCart } from "@/lib/hooks/use-cart"
import { useFavorites } from "@/lib/providers/favorites-provider"
import { useWatchlist } from "@/lib/hooks/use-watchlist"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"
import { cn } from "@/lib/utils"
import { useTheme } from "next-themes"
import { motion } from "framer-motion"

export default function Navbar() {
  const pathname = usePathname()
  const [isScrolled, setIsScrolled] = useState(false)
  const { cart } = useCart()
  const { favorites } = useFavorites()
  const { watchlist } = useWatchlist()
  const { isAuthenticated: isOwnerAuthenticated } = useOwnerAuth()
  const [mounted, setMounted] = useState(false)
  const { theme, setTheme } = useTheme()

  useEffect(() => {
    setMounted(true)

    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  if (!mounted) {
    return null
  }

  const isHomePage = pathname === "/"
  const navLinks = [
    { href: "/", label: "Home", icon: Home },
    { href: "/listings", label: "Listings", icon: Search },
    { href: "/favorites", label: "Favorites", icon: Heart, count: favorites.length },
    { href: "/watchlist", label: "Watchlist", icon: Calendar, count: watchlist.length },
    { href: "/cart", label: "Cart", icon: ShoppingCart, count: cart.length },
    { href: "/bookings", label: "Bookings", icon: Calendar },
  ]

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 100, damping: 20 }}
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out",
        isHomePage && !isScrolled ? "bg-primary/90 backdrop-blur-sm py-4" : "bg-primary shadow-md py-2",
      )}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link
              href="/"
              className="text-2xl font-bold text-primary-foreground transition-all duration-300 hover:scale-105"
            >
              Venme
            </Link>
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href} className="relative">
                <motion.div whileHover={{ scale: 1.05 }}>
                  <Button
                    variant="ghost"
                    className={cn(
                      "text-primary-foreground hover:bg-primary-foreground/20 hover:text-primary-foreground transition-all duration-200",
                      pathname === link.href && "bg-primary-foreground/20 font-medium",
                    )}
                  >
                    <link.icon className="h-5 w-5 mr-2" />
                    {link.label}
                    {link.count > 0 && (
                      <span className="absolute -top-1 -right-1 bg-accent text-accent-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {link.count}
                      </span>
                    )}
                  </Button>
                </motion.div>
              </Link>
            ))}

            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="text-primary-foreground hover:bg-primary-foreground/20 hover:text-primary-foreground transition-all duration-200"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            </motion.div>

            {isOwnerAuthenticated() ? (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Link href="/owner/dashboard">
                  <Button
                    variant="outline"
                    className="ml-2 border-accent text-accent hover:bg-accent/10 transition-all duration-200 shadow-md"
                  >
                    Owner Dashboard
                  </Button>
                </Link>
              </motion.div>
            ) : (
              <>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Link href="/customer/login">
                    <Button
                      variant="outline"
                      className="ml-2 border-primary-foreground text-primary-foreground hover:bg-primary-foreground/20 transition-all duration-200 shadow-md"
                    >
                      <User className="h-5 w-5 mr-2" />
                      Login
                    </Button>
                  </Link>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Link href="/owner/login">
                    <Button
                      variant="outline"
                      className="ml-2 border-accent text-accent hover:bg-accent/10 transition-all duration-200 shadow-md"
                    >
                      <LogIn className="h-5 w-5 mr-2" />
                      Owner
                    </Button>
                  </Link>
                </motion.div>
              </>
            )}
          </nav>

          {/* Mobile Navigation */}
          <div className="flex items-center md:hidden">
            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="text-primary-foreground hover:bg-primary-foreground/20 mr-2 transition-all duration-200"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            </motion.div>

            <Sheet>
              <SheetTrigger asChild>
                <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-primary-foreground hover:bg-primary-foreground/20"
                  >
                    <Menu className="h-6 w-6" />
                  </Button>
                </motion.div>
              </SheetTrigger>
              <SheetContent>
                <div className="text-2xl font-bold mb-6 mt-4">Venme</div>
                <nav className="flex flex-col space-y-4">
                  {navLinks.map((link, index) => (
                    <motion.div
                      key={link.href}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 * index }}
                    >
                      <Link
                        href={link.href}
                        className={cn(
                          "py-2 px-4 rounded-md flex items-center transition-all duration-200 hover:bg-accent/10",
                          pathname === link.href ? "bg-accent/20 font-medium" : "",
                        )}
                      >
                        <link.icon className="h-5 w-5 mr-2" />
                        {link.label}
                        {link.count > 0 && (
                          <span className="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-accent-foreground bg-accent rounded-full">
                            {link.count}
                          </span>
                        )}
                      </Link>
                    </motion.div>
                  ))}
                  {isOwnerAuthenticated() ? (
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.6 }}
                    >
                      <Link
                        href="/owner/dashboard"
                        className="py-2 px-4 rounded-md flex items-center transition-all duration-200 bg-accent text-accent-foreground"
                      >
                        Owner Dashboard
                      </Link>
                    </motion.div>
                  ) : (
                    <>
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.6 }}
                      >
                        <Link
                          href="/customer/login"
                          className="py-2 px-4 rounded-md flex items-center transition-all duration-200 border border-accent"
                        >
                          <User className="h-5 w-5 mr-2" />
                          Login
                        </Link>
                      </motion.div>
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.7 }}
                      >
                        <Link
                          href="/owner/login"
                          className="py-2 px-4 rounded-md flex items-center transition-all duration-200 bg-accent text-accent-foreground"
                        >
                          <LogIn className="h-5 w-5 mr-2" />
                          Owner
                        </Link>
                      </motion.div>
                    </>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </motion.header>
  )
}

