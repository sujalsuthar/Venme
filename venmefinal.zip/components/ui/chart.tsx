import type * as React from "react"

const Chart = () => {
  return null
}

const ChartContainer = ({ children }: { children: React.ReactNode }) => {
  return <div className="w-full">{children}</div>
}

const ChartTooltip = () => {
  return null
}

const ChartTooltipContent = () => {
  return null
}

const ChartTooltipItem = () => {
  return null
}

const ChartLegend = () => {
  return null
}

const ChartLegendItem = () => {
  return null
}

export { Chart, ChartContainer, ChartTooltip, ChartTooltipContent, ChartTooltipItem, ChartLegend, ChartLegendItem }

