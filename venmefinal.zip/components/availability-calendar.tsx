"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

interface AvailabilityCalendarProps {
  listingId: string
  bookedDates?: Date[]
  onDateSelect: (date: Date) => void
}

export default function AvailabilityCalendar({ listingId, bookedDates = [], onDateSelect }: AvailabilityCalendarProps) {
  const { toast } = useToast()
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined)

  // Add 3 months to current date for max date
  const maxDate = new Date()
  maxDate.setMonth(maxDate.getMonth() + 3)

  // Disable past dates and booked dates
  const disabledDates = [...bookedDates.map((date) => new Date(date)), { before: new Date() }, { after: maxDate }]

  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return

    // Check if date is already booked
    const isBooked = bookedDates.some((bookedDate) => {
      const bookedDateObj = new Date(bookedDate)
      return bookedDateObj.toDateString() === date.toDateString()
    })

    if (isBooked) {
      toast({
        title: "Date Unavailable",
        description: "This date is already booked. Please select another date.",
        variant: "destructive",
      })
      return
    }

    setSelectedDate(date)
  }

  const handleConfirm = () => {
    if (selectedDate) {
      onDateSelect(selectedDate)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Select Date</CardTitle>
      </CardHeader>
      <CardContent>
        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={handleDateSelect}
          disabled={disabledDates}
          className="rounded-md border"
          modifiers={{
            booked: bookedDates.map((date) => new Date(date)),
          }}
          modifiersStyles={{
            booked: { color: "red", textDecoration: "line-through" },
          }}
          components={{
            DayContent: (props) => {
              const isBooked = bookedDates.some((date) => {
                const bookedDateObj = new Date(date)
                return bookedDateObj.toDateString() === props.date.toDateString()
              })

              return (
                <div className={cn("relative flex h-8 w-8 items-center justify-center", isBooked && "bg-red-100")}>
                  <div>{props.date.getDate()}</div>
                  {isBooked && (
                    <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-red-500 rounded-full" />
                  )}
                </div>
              )
            },
          }}
        />

        <div className="mt-4 flex justify-between items-center">
          <div className="flex items-center text-sm">
            <div className="w-3 h-3 bg-red-100 rounded-full mr-2"></div>
            <span>Booked</span>
          </div>
          <Button onClick={handleConfirm} disabled={!selectedDate} className="bg-primary hover:bg-primary/90">
            Confirm Date
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

