"use client"

import { useRef } from "react"
import { useRecentlyViewed } from "@/lib/hooks/use-recently-viewed"
import ListingCard from "./listing-card"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { motion, useInView } from "framer-motion"

export default function RecentlyViewed() {
  const router = useRouter()
  const { recentlyViewed } = useRecentlyViewed()
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  if (recentlyViewed.length === 0) {
    return null
  }

  const handleViewAll = () => {
    router.push("/listings")
  }

  return (
    <section ref={ref} className="py-12">
      <motion.div
        className="container mx-auto px-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: isInView ? 1 : 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div
          className="flex justify-between items-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isInView ? 1 : 0, y: isInView ? 0 : 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h2 className="text-2xl font-bold">Recently Viewed</h2>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={handleViewAll}
              variant="outline"
              className="border-primary text-primary hover:bg-primary/5"
            >
              View All Listings
            </Button>
          </motion.div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {recentlyViewed.slice(0, 4).map((listing, index) => (
            <ListingCard key={listing.id} listing={listing} index={index} />
          ))}
        </div>
      </motion.div>
    </section>
  )
}

