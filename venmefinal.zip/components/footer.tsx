"use client"

import Link from "next/link"
import { Facebook, Instagram, Twitter, Linkedin, Mail, Phone, MapPin } from "lucide-react"
import { motion } from "framer-motion"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <motion.footer
      className="bg-primary text-primary-foreground mt-16 relative z-10"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, amount: 0.1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h3 className="text-xl font-bold mb-4">Party Plot Rental</h3>
            <p className="text-white/80 mb-4">
              Find and book the perfect venue for your special occasions. We offer a wide range of party plots for
              weddings, corporate events, and celebrations.
            </p>
            <div className="flex space-x-4">
              {[
                { icon: Facebook, href: "https://facebook.com" },
                { icon: Instagram, href: "https://instagram.com" },
                { icon: Twitter, href: "https://twitter.com" },
                { icon: Linkedin, href: "https://linkedin.com" },
              ].map((social, index) => (
                <motion.div key={social.href} whileHover={{ scale: 1.2, y: -5 }} whileTap={{ scale: 0.9 }}>
                  <Link href={social.href} target="_blank" className="hover:text-accent transition-colors">
                    <social.icon className="h-5 w-5" />
                  </Link>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {[
                { label: "Home", href: "/" },
                { label: "Listings", href: "/listings" },
                { label: "About Us", href: "/about" },
                { label: "Contact", href: "/contact" },
                { label: "Owner Login", href: "/owner/login" },
                { label: "Lotus Owner Login", href: "/owner/lotus-login" },
              ].map((link) => (
                <motion.li key={link.href} whileHover={{ x: 5 }}>
                  <Link href={link.href} className="hover:text-accent transition-colors">
                    {link.label}
                  </Link>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              {[
                { label: "Terms of Service", href: "/terms" },
                { label: "Privacy Policy", href: "/privacy" },
                { label: "Refund Policy", href: "/refund" },
                { label: "FAQ", href: "/faq" },
              ].map((link) => (
                <motion.li key={link.href} whileHover={{ x: 5 }}>
                  <Link href={link.href} className="hover:text-accent transition-colors">
                    {link.label}
                  </Link>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <motion.li className="flex items-center" whileHover={{ x: 5 }}>
                <Mail className="h-5 w-5 mr-2" />
                <a href="mailto:info@partyplot.com" className="hover:text-accent transition-colors">
                  info@partyplot.com
                </a>
              </motion.li>
              <motion.li className="flex items-center" whileHover={{ x: 5 }}>
                <Phone className="h-5 w-5 mr-2" />
                <a href="tel:+919876543210" className="hover:text-accent transition-colors">
                  +91 98765 43210
                </a>
              </motion.li>
              <motion.li className="flex items-start mt-2" whileHover={{ x: 5 }}>
                <MapPin className="h-5 w-5 mr-2 mt-1" />
                <p className="text-white/80">
                  123 Main Street, Mumbai,
                  <br />
                  Maharashtra, India - 400001
                </p>
              </motion.li>
            </ul>
          </motion.div>
        </div>

        <motion.div
          className="border-t border-white/20 mt-8 pt-8 text-center text-white/80"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <p>© {currentYear} Party Plot Rental. All rights reserved.</p>
        </motion.div>
      </div>
    </motion.footer>
  )
}

