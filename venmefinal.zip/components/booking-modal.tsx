"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { useBookings } from "@/lib/hooks/use-bookings"
import type { Listing } from "@/lib/types"

interface BookingModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  listings: Listing[]
}

export default function BookingModal({ isOpen, onClose, onConfirm, listings }: BookingModalProps) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [isCalendarOpen, setIsCalendarOpen] = useState(false)
  const { addBooking } = useBookings()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !email || !date) {
      return
    }

    // Add bookings
    listings.forEach((listing) => {
      addBooking({
        id: Math.random().toString(36).substring(2, 11),
        plotName: listing.name,
        location: listing.location,
        eventDate: date.toISOString(),
        status: "confirmed",
        price: listing.price,
      })
    })

    onConfirm()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Book Your Event</DialogTitle>
          <DialogDescription>Fill in the details to book your party plot.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your full name"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="date">Event Date</Label>
              <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                <PopoverTrigger asChild>
                  <Button
                    id="date"
                    variant="outline"
                    className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select event date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(date) => {
                      setDate(date)
                      setIsCalendarOpen(false)
                    }}
                    initialFocus
                    disabled={(date) => date < new Date()}
                  />
                </PopoverContent>
              </Popover>
            </div>

            {listings.length > 0 && (
              <div className="border rounded-md p-3 bg-gray-50">
                <h4 className="font-medium mb-2">Booking Summary</h4>
                {listings.map((listing, index) => (
                  <div
                    key={listing.id}
                    className={cn("text-sm", index !== listings.length - 1 && "mb-2 pb-2 border-b")}
                  >
                    <p className="font-medium">{listing.name}</p>
                    <p className="text-gray-500">{listing.location}</p>
                    <p className="font-medium">₹{listing.price.toLocaleString()}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-[#0A2647] hover:bg-[#0A2647]/90">
              Confirm Booking
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

