"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useCart } from "@/lib/hooks/use-cart"
import { useWatchlist } from "@/lib/hooks/use-watchlist"
import type { Listing } from "@/lib/types"
import Image from "next/image"
import { Star } from "lucide-react"

export default function WatchlistPage() {
  const { toast } = useToast()
  const { watchlist, removeFromWatchlist } = useWatchlist()
  const { addToCart } = useCart()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  const handleAddToCart = (listing: Listing) => {
    addToCart(listing)
    toast({
      title: "Added to cart",
      description: `${listing.name} has been added to your cart.`,
    })
  }

  const handleRemoveFromWatchlist = (id: string) => {
    removeFromWatchlist(id)
    toast({
      title: "Removed from watchlist",
      description: "The item has been removed from your watchlist.",
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Your Watchlist</h1>

      {watchlist.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-2xl font-medium mb-2">Your watchlist is empty</h2>
          <p className="text-gray-500 mb-6">Browse our listings and add your favorite party plots to your watchlist.</p>
          <Button href="/listings" className="bg-[#0A2647] hover:bg-[#0A2647]/90">
            Browse Listings
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {watchlist.map((listing) => (
            <div
              key={listing.id}
              className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-[1.02]"
            >
              <div className="relative h-48">
                <Image src={listing.image || "/placeholder.svg"} alt={listing.name} fill className="object-cover" />
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-semibold">{listing.name}</h3>
                  <div className="flex items-center bg-[#FFD700] px-2 py-1 rounded text-sm">
                    <Star className="h-4 w-4 mr-1 fill-current" />
                    {listing.rating}
                  </div>
                </div>
                <p className="text-gray-500 mb-2">{listing.location}</p>
                <p className="text-lg font-bold mb-4">₹{listing.price.toLocaleString()}</p>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => handleAddToCart(listing)}
                    className="flex-1 bg-[#0A2647] hover:bg-[#0A2647]/90"
                  >
                    Add to Cart
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleRemoveFromWatchlist(listing.id)}
                    className="flex-1 border-[#FF6B6B] text-[#FF6B6B] hover:bg-[#FF6B6B]/10"
                  >
                    Remove
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

