"use client"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { MapPin, Phone, Mail, Globe, Clock, ShipWheelIcon as Wheelchair, Music } from "lucide-react"
import { useRouter } from "next/navigation"

export default function AboutPage() {
  const router = useRouter()

  // Images for the gallery
  const images = [
    "https://media-hosting.imagekit.io//63a46695cb304f82/4.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=IYr49cfJpNzNpgCCCW5m~yarhqtZ1ORotWGYYRO30sWA95sm1ZA2t~gP2OsJOkZAGFU7Z471vX7UfFLJcieYiunp3IHx7l0F0WQp4d5~e-Y~9jmLiONnvoVaHy1-6uFWPJvHWTyk2SD5OzxPvccrv0-X7BSxCcAVmjfBWK7z5hsXd1bh333nA-oXBXUgPA37oVmPMPsNdAhSGW7-~JE14YvBAzYReOF~01cnLB413cq5TCpdfp0imw0vMcwZvSvPddyDdp0xV-txEgqCjsbmRC1SwG0DRjP0awbr3uG-XIvd2LHfBVFtvCgW6LjRkH~sf3bPnYhaqpVVKj6hTyLW6w__",
    "https://media-hosting.imagekit.io//4d0e9f7ade984383/2.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=Czqy-FFwJZ5OqlyUb-7cxJLVDYXPPvyb8N~Nsa4iwXsifffG9nSnQnNFkwnPJeVHEBDnkzU1cvsAMJPH5RghaXhQR-pbn7PH95zQO1l3PsNmDacgk0TN3f0EgbRpccS5XKJqvmRByIe~K7nZ8ylEb8dgmrwZ3h7eAaZH9y0omTT7RpgHip4ZQyZdAVxBalJ19~MVSIuE-MdSs-Cv~2k91dTUjp2mv8azeOi48dmdM9aoku2VivIg4O~1hAmGwXUB5LiHi5FbcnkU2Hml-zugzT-QA5GTPmar1WdQjqf9WsI0RdSG7VzFGu96sv0uxnke~I1~EPmDlU8RrBwRe4lT2g__",
    "https://media-hosting.imagekit.io//2ba1438b192b4038/1.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=nnug668lshxMZnmXLcVyiSPq5yCH63lQTdj2WLgWuYG4LhEDKXvUvTaRtceEckcIC8GfhKeszZIX4LQDzIzkESm~L5qTLCEgGkqEHflQAX60lsLyONeU0aeupBEQGZiWvE3HBAuTEEsZ5LDeXW6CkDeQxbJpPHLIihA9C26cqeWQbaMn3UCCHQzx7xEhcs4dYpiDruASL3kg-CE75i4H7In~8bPdk2SkW1BPa7YCaRFG1gJRfYzoGUlajlAgwHS9JJqWDivRk7c14-DRQa-F9VJXF2LHDwJNnitJHov0yjS5A6aa9ta4KJbulOcLN4CV-NHB9vPL4w6N-v4u7tn79w__",
    "https://media-hosting.imagekit.io//0488c6bd86a04e2c/3.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=aDR2Rfc-sgY3FAsfAeBmcWALg6-4kdWlJ-L8nFxnfjy8lYxzmNOY231AUa-6CUvvEQ8FxOE5JlSaa~v6ovIfGsnGN0Jd08xNB8poBOjiDjudc0Xo4LRN5-0oO3shB6l-SA93NiAq61~uAGURzLyRu9KMYH75BdSFjAIc~lid69OCnI6gNRg3yl82FH17XIMLeO53mUwtRWXyfTwjJdqod1a2ohHZq9fMChGKrcojmSn4Pz3tJZphbtXrSgagrse2P4r0f5ToNkIhynsoPhOlERHWyxHZm4l6CQhw7V1xc2TuGsHjKJeR~voKNxZRkAZCnk7wgxFPROdRoIac79b48Q__",
    "https://media-hosting.imagekit.io//ea7687224c804b57/5.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=anWXGFJGsWRkJv9PsltSWsIErapIh~7gcRAH8sYUMQfO~sXI7mTz3Y~btdm1hi-5rKOd6tJ4GV8BkihKIBAOcmtRIGHYaFdVGbg6THqEyt2iN3HSzZBJhPdgvOyyTw0MxasS07dI4MObRC1MC7Z3YZ68OlmAEOq3R0yhh0V8dDX0rYa6hypCmmFidSJycwMntAAkk3wmCimyVqwz3C1fgvyDcbYmL3oAi-aXvhnm2CFRgseldMYaAaVPz6VcrOieD1kDvvSYEXp8WXRysG62ps0vHBbuLfiJlrfQ27SQqceb~kkON0vWHb6OA5bYLJQRZvbnT4Ergigv1s6qJhBzvw__",
    "https://media-hosting.imagekit.io//120fb344eaff4f0a/6.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=tCvVVkDt7Bi6T1L18-agbMgWqlKs~NoCOkSkO0fBmpiWvUksxZT-S0eRAdomsiTY5B~spnXQIMI-r7jMpAX8ESq2eyT4GbM1vJW3jf8vslT1a6Mb2uXYWRYVMf63w7gIfKCO7uIvQ1hwxGoaUHebRUuL~lycuuH6ki1etkCX~oG2~gYKolxTaVcg7gBvVio68iQVHNN3iSx~3T9r1tucMWkN7v~AVeMnzMeZ0GLacSkAzkAYRgtz9HMy-kcn1iPjtrSd6n0yqi6MnGe2FlChjDoBP8t8djg00fP3EbXFLYLz0GrJmauEjYkpR6r36h5JhQjboMB9BBdD1MnIz81TLQ__",
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative h-[60vh] w-full">
        <Image
          src={images[0] || "/placeholder.svg"}
          alt="The Grand Lotus Banquets"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center text-white p-6">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center">The Grand Lotus Banquets</h1>
          <p className="text-xl md:text-2xl mb-8 text-center max-w-3xl">
            Premier event venue for all your celebrations
          </p>
          <Button
            onClick={() => router.push("/listings/lotus-banquet")}
            className="bg-accent text-primary hover:bg-accent/90"
          >
            View Details
          </Button>
        </div>
      </div>

      {/* About Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-primary">About The Grand Lotus Banquets</h2>
          <p className="text-lg mb-6">
            Welcome to <strong>The Grand Lotus Banquets</strong>, a premier event venue located in the heart of
            Ahmedabad. Situated near <strong>Nayara Petrol Pump</strong>, opposite <strong>Satyamev Vista</strong> on
            the <strong>Off-road Sarkhej-Gandhinagar Highway</strong>, our banquet hall is the perfect destination for
            all your celebrations and special occasions.
          </p>

          <h3 className="text-2xl font-bold mt-10 mb-4 text-primary">Why Choose Us?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
            <div className="flex items-start">
              <MapPin className="h-6 w-6 mr-3 text-accent flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-lg mb-2">Prime Location</h4>
                <p>Easily accessible from major areas of Ahmedabad.</p>
              </div>
            </div>
            <div className="flex items-start">
              <Music className="h-6 w-6 mr-3 text-accent flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-lg mb-2">Spacious Venue</h4>
                <p>Ample space to host weddings, corporate events, parties, and more.</p>
              </div>
            </div>
            <div className="flex items-start">
              <Wheelchair className="h-6 w-6 mr-3 text-accent flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-lg mb-2">Modern Amenities</h4>
                <ul className="list-disc list-inside ml-2">
                  <li>Free parking for guests</li>
                  <li>Well-maintained restrooms</li>
                  <li>Wheelchair accessibility</li>
                </ul>
              </div>
            </div>
            <div className="flex items-start">
              <Clock className="h-6 w-6 mr-3 text-accent flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-lg mb-2">Elegant Ambiance</h4>
                <p>A beautifully designed space to make your event memorable.</p>
              </div>
            </div>
          </div>

          <p className="text-lg mb-10">
            At <strong>The Grand Lotus Banquets</strong>, we are committed to providing a seamless and unforgettable
            experience for you and your guests. Let us help you create moments that last a lifetime.
          </p>

          <h3 className="text-2xl font-bold mt-10 mb-4 text-primary">Key Features</h3>
          <ul className="space-y-3 mb-10">
            <li className="flex items-center">
              <span className="h-2 w-2 rounded-full bg-accent mr-3"></span>
              <span>
                <strong>Capacity:</strong> Accommodates up to 500 guests
              </span>
            </li>
            <li className="flex items-start">
              <span className="h-2 w-2 rounded-full bg-accent mr-3 mt-2"></span>
              <div>
                <strong>Facilities:</strong>
                <ul className="list-disc list-inside ml-6 mt-1">
                  <li>Air-conditioned halls</li>
                  <li>State-of-the-art sound and lighting systems</li>
                  <li>Dedicated event planning support</li>
                </ul>
              </div>
            </li>
            <li className="flex items-center">
              <span className="h-2 w-2 rounded-full bg-accent mr-3"></span>
              <span>
                <strong>Catering:</strong> Customizable menus to suit your preferences
              </span>
            </li>
          </ul>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="bg-secondary/10 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-10 text-center text-primary">Gallery</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {images.map((img, index) => (
              <div
                key={index}
                className="aspect-video relative rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
              >
                <Image
                  src={img || "/placeholder.svg"}
                  alt={`The Grand Lotus Banquets - Image ${index + 1}`}
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-10 text-primary">Visit Us</h2>
          <div className="bg-primary/5 p-6 rounded-lg shadow-md">
            <div className="space-y-4">
              <div className="flex items-start">
                <MapPin className="h-6 w-6 mr-3 text-primary flex-shrink-0 mt-1" />
                <p>
                  <strong>Address:</strong> Near Nayara Petrol Pump, Opposite Satyamev Vista, Off-road
                  Sarkhej-Gandhinagar Highway, Ahmedabad.
                </p>
              </div>
              <div className="flex items-center">
                <Phone className="h-6 w-6 mr-3 text-primary flex-shrink-0" />
                <p>
                  <strong>Contact:</strong> +91 98765 43210
                </p>
              </div>
              <div className="flex items-center">
                <Mail className="h-6 w-6 mr-3 text-primary flex-shrink-0" />
                <p>
                  <strong>Email:</strong> info@grandlotusbanquets.com
                </p>
              </div>
              <div className="flex items-center">
                <Globe className="h-6 w-6 mr-3 text-primary flex-shrink-0" />
                <p>
                  <strong>Website:</strong> www.grandlotusbanquets.com
                </p>
              </div>
            </div>
          </div>

          <div className="mt-10 flex justify-center">
            <Button
              onClick={() => router.push("/listings/lotus-banquet")}
              className="bg-accent text-primary hover:bg-accent/90"
            >
              Book Now
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

