"use client"

import { useState, useEffect } from "react"
import { useFavorites } from "@/lib/providers/favorites-provider"
import ListingCard from "@/components/listing-card"
import { Button } from "@/components/ui/button"
import { Heart } from "lucide-react"
import Link from "next/link"

export default function FavoritesPage() {
  const { favorites, clearFavorites } = useFavorites()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Your Favorites</h1>

      {favorites.length > 0 ? (
        <>
          <div className="flex justify-between items-center mb-6">
            <p className="text-gray-600">{favorites.length} venues saved</p>
            <Button variant="outline" onClick={clearFavorites}>
              Clear All
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favorites.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        </>
      ) : (
        <div className="text-center py-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
            <Heart className="h-8 w-8 text-gray-400" />
          </div>
          <h2 className="text-2xl font-semibold mb-2">No favorites yet</h2>
          <p className="text-gray-600 mb-6">Save your favorite venues by clicking the heart icon on any listing</p>
          <Link href="/listings">
            <Button>Browse Listings</Button>
          </Link>
        </div>
      )}
    </div>
  )
}

