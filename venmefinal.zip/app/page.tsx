"use client"
import { useRouter } from "next/navigation"
import Hero from "@/components/hero"
import FeaturedListings from "@/components/featured-listings"
import RecentlyViewed from "@/components/recently-viewed"
import Testimonials from "@/components/testimonials"
import SpecialOffers from "@/components/special-offers"

export default function Home() {
  const router = useRouter()

  return (
    <main className="min-h-screen">
      <Hero />
      <div className="container mx-auto px-4 py-12">
        <SpecialOffers />
        <h2 className="text-3xl font-bold mb-8 text-center">Featured Party Plots</h2>
        <FeaturedListings />
        <RecentlyViewed />
        <Testimonials />
      </div>
    </main>
  )
}

