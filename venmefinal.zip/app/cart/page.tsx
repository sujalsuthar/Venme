"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useCart } from "@/lib/hooks/use-cart"
import Image from "next/image"
import { Trash2, ShoppingCart, ArrowRight } from "lucide-react"
import BookingModal from "@/components/booking-modal"
import { Input } from "@/components/ui/input"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useRouter } from "next/navigation"
import PaymentForm from "@/components/payment-form"

export default function CartPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { cart, removeFromCart, clearCart } = useCart()
  const [mounted, setMounted] = useState(false)
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false)
  const [promoCode, setPromoCode] = useState("")
  const [discount, setDiscount] = useState(0)
  const [isApplyingPromo, setIsApplyingPromo] = useState(false)
  const [showPayment, setShowPayment] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  const subtotal = cart.reduce((total, item) => {
    const itemPrice = item.price * (1 - (item.discount || 0) / 100)
    return total + itemPrice
  }, 0)

  const serviceFee = subtotal * 0.05
  const promoDiscount = subtotal * (discount / 100)
  const totalAmount = subtotal + serviceFee - promoDiscount

  const handleRemoveFromCart = (id: string) => {
    removeFromCart(id)
    toast({
      title: "Removed from cart",
      description: "The item has been removed from your cart.",
    })
  }

  const handleApplyPromoCode = () => {
    setIsApplyingPromo(true)

    // Simulate API call to validate promo code
    setTimeout(() => {
      const validPromoCodes = {
        WELCOME10: 10,
        SUMMER20: 20,
        MONSOON15: 15,
        WEDDING10: 10,
        CORP20: 20,
      }

      const code = promoCode.toUpperCase()
      if (code in validPromoCodes) {
        setDiscount(validPromoCodes[code as keyof typeof validPromoCodes])
        toast({
          title: "Promo code applied",
          description: `You got ${validPromoCodes[code as keyof typeof validPromoCodes]}% off!`,
        })
      } else {
        toast({
          title: "Invalid promo code",
          description: "The promo code you entered is invalid or expired.",
          variant: "destructive",
        })
      }

      setIsApplyingPromo(false)
    }, 1000)
  }

  const handleProceedToCheckout = () => {
    setShowPayment(true)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Your Cart</h1>

      {cart.length === 0 ? (
        <div className="text-center py-12">
          <div className="flex justify-center mb-6">
            <ShoppingCart className="h-24 w-24 text-gray-300" />
          </div>
          <h2 className="text-2xl font-medium mb-2">Your cart is empty</h2>
          <p className="text-gray-500 mb-6">Browse our listings and add party plots to your cart.</p>
          <Button onClick={() => router.push("/listings")} className="bg-[#0A2647] hover:bg-[#0A2647]/90">
            Browse Listings
          </Button>
        </div>
      ) : (
        <>
          {!showPayment ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-4">
                {cart.map((item) => (
                  <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden flex">
                    <div className="relative w-1/3 h-auto">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        width={200}
                        height={150}
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">{item.name}</h3>
                        <p className="text-gray-500">{item.location}</p>
                        <div className="flex items-baseline mt-2">
                          <p className="text-lg font-bold">
                            ₹{(item.price * (1 - (item.discount || 0) / 100)).toLocaleString()}
                          </p>
                          {item.discount > 0 && (
                            <p className="text-sm text-gray-500 line-through ml-2">₹{item.price.toLocaleString()}</p>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveFromCart(item.id)}
                        className="self-end text-[#FF6B6B] hover:text-[#FF6B6B] hover:bg-[#FF6B6B]/10"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}

                <div className="bg-white rounded-lg shadow-md p-6 mt-6">
                  <h3 className="text-lg font-semibold mb-4">Have a Promo Code?</h3>
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Enter promo code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="flex-grow"
                    />
                    <Button
                      onClick={handleApplyPromoCode}
                      disabled={!promoCode || isApplyingPromo}
                      className="bg-[#0A2647] hover:bg-[#0A2647]/90"
                    >
                      {isApplyingPromo ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      ) : (
                        "Apply"
                      )}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6 h-fit">
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span>Subtotal ({cart.length} items)</span>
                    <span>₹{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Service Fee (5%)</span>
                    <span>₹{serviceFee.toLocaleString()}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Promo Discount ({discount}%)</span>
                      <span>-₹{promoDiscount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="border-t pt-2 mt-2 flex justify-between font-bold">
                    <span>Total</span>
                    <span>₹{totalAmount.toLocaleString()}</span>
                  </div>
                </div>

                <Button onClick={handleProceedToCheckout} className="w-full bg-[#0A2647] hover:bg-[#0A2647]/90">
                  Proceed to Checkout
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>

                <Accordion type="single" collapsible className="w-full mt-6">
                  <AccordionItem value="item-1">
                    <AccordionTrigger className="text-sm">View Cancellation Policy</AccordionTrigger>
                    <AccordionContent>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• Full refund if cancelled 30+ days before event</li>
                        <li>• 50% refund if cancelled 15-29 days before event</li>
                        <li>• No refund if cancelled less than 15 days before event</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <PaymentForm
                  amount={totalAmount}
                  onSuccess={() => {
                    clearCart()
                    router.push("/bookings")
                    toast({
                      title: "Payment Successful",
                      description: "Your booking has been confirmed. Check your email for details.",
                    })
                  }}
                  onCancel={() => setShowPayment(false)}
                />
              </div>

              <div className="bg-white rounded-lg shadow-md p-6 h-fit">
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between">
                    <span>Subtotal ({cart.length} items)</span>
                    <span>₹{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Service Fee (5%)</span>
                    <span>₹{serviceFee.toLocaleString()}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Promo Discount ({discount}%)</span>
                      <span>-₹{promoDiscount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="border-t pt-2 mt-2 flex justify-between font-bold">
                    <span>Total</span>
                    <span>₹{totalAmount.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-2">Your Booking Details</h3>
                  <div className="space-y-2 text-sm">
                    {cart.map((item) => (
                      <div key={item.id} className="flex justify-between">
                        <span>{item.name}</span>
                        <span>₹{(item.price * (1 - (item.discount || 0) / 100)).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        onConfirm={() => {
          clearCart()
          setIsBookingModalOpen(false)
          toast({
            title: "Booking Confirmed",
            description: "Your booking has been confirmed. Check your email for details.",
          })
        }}
        listings={cart}
      />
    </div>
  )
}

