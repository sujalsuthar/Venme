"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"
import OwnerLayout from "@/components/owner-layout"
import { Calendar, CreditCard, Download, Search } from "lucide-react"
import { DataTable } from "@/components/ui/data-table"
import type { ColumnDef } from "@tanstack/react-table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import type { DateRange } from "react-day-picker"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

interface Payment {
  id: string
  bookingId: string
  plotName: string
  customerName: string
  amount: number
  status: "paid" | "pending" | "refunded"
  paymentMethod: string
  date: string
}

const mockPayments: Payment[] = [
  {
    id: "1",
    bookingId: "B001",
    plotName: "Royal Garden Party Plot",
    customerName: "Rahul Sharma",
    amount: 25000,
    status: "paid",
    paymentMethod: "Credit Card",
    date: "2024-03-01T10:30:00Z",
  },
  {
    id: "2",
    bookingId: "B002",
    plotName: "Sunset Beach Venue",
    customerName: "Priya Patel",
    amount: 35000,
    status: "pending",
    paymentMethod: "Bank Transfer",
    date: "2024-03-05T14:45:00Z",
  },
  {
    id: "3",
    bookingId: "B003",
    plotName: "Mountain View Resort",
    customerName: "Amit Kumar",
    amount: 40000,
    status: "paid",
    paymentMethod: "UPI",
    date: "2024-03-10T09:15:00Z",
  },
  {
    id: "4",
    bookingId: "B004",
    plotName: "City Lights Banquet",
    customerName: "Neha Gupta",
    amount: 30000,
    status: "refunded",
    paymentMethod: "Credit Card",
    date: "2024-03-15T18:00:00Z",
  },
  {
    id: "5",
    bookingId: "B005",
    plotName: "Heritage Palace",
    customerName: "Vikram Singh",
    amount: 50000,
    status: "paid",
    paymentMethod: "Debit Card",
    date: "2024-03-20T11:30:00Z",
  },
]

export default function OwnerPaymentsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { isAuthenticated } = useOwnerAuth()
  const [mounted, setMounted] = useState(false)
  const [payments, setPayments] = useState<Payment[]>(mockPayments)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateRange, setDateRange] = useState<DateRange | undefined>()

  useEffect(() => {
    setMounted(true)

    if (mounted && !isAuthenticated()) {
      router.push("/owner/login")
    }
  }, [mounted, isAuthenticated, router])

  if (!mounted || !isAuthenticated()) {
    return null
  }

  const columns: ColumnDef<Payment>[] = [
    {
      accessorKey: "date",
      header: "Date",
      cell: ({ row }) => format(new Date(row.getValue("date")), "dd MMM yyyy"),
    },
    {
      accessorKey: "bookingId",
      header: "Booking ID",
    },
    {
      accessorKey: "plotName",
      header: "Plot Name",
    },
    {
      accessorKey: "customerName",
      header: "Customer",
    },
    {
      accessorKey: "amount",
      header: "Amount",
      cell: ({ row }) => `₹${row.getValue("amount").toLocaleString()}`,
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.getValue("status") as string
        return (
          <Badge className={status === "paid" ? "bg-green-500" : status === "pending" ? "bg-amber-500" : "bg-red-500"}>
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Badge>
        )
      },
    },
    {
      accessorKey: "paymentMethod",
      header: "Payment Method",
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const payment = row.original
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <circle cx="12" cy="12" r="1" />
                  <circle cx="12" cy="5" r="1" />
                  <circle cx="12" cy="19" r="1" />
                </svg>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => router.push(`/owner/bookings/${payment.bookingId}`)}>
                View Booking
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleGenerateInvoice(payment)}>Generate Invoice</DropdownMenuItem>
              {payment.status === "pending" && (
                <DropdownMenuItem onClick={() => handleMarkAsPaid(payment.id)}>Mark as Paid</DropdownMenuItem>
              )}
              {payment.status === "paid" && (
                <DropdownMenuItem onClick={() => handleInitiateRefund(payment.id)}>Initiate Refund</DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        )
      },
    },
  ]

  const handleGenerateInvoice = (payment: Payment) => {
    // In a real app, this would generate and download a PDF invoice
    toast({
      title: "Invoice generated",
      description: `Invoice for ${payment.customerName} has been generated.`,
    })
  }

  const handleMarkAsPaid = (paymentId: string) => {
    setPayments(payments.map((p) => (p.id === paymentId ? { ...p, status: "paid" } : p)))
    toast({
      title: "Payment marked as paid",
      description: "The payment status has been updated successfully.",
    })
  }

  const handleInitiateRefund = (paymentId: string) => {
    setPayments(payments.map((p) => (p.id === paymentId ? { ...p, status: "refunded" } : p)))
    toast({
      title: "Refund initiated",
      description: "The refund process has been initiated successfully.",
    })
  }

  // Filter payments
  const filteredPayments = payments.filter((payment) => {
    const matchesSearch =
      payment.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.plotName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      payment.bookingId.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || payment.status === statusFilter

    let matchesDateRange = true
    if (dateRange?.from) {
      const paymentDate = new Date(payment.date)
      const fromDate = new Date(dateRange.from)
      fromDate.setHours(0, 0, 0, 0)

      if (dateRange.to) {
        const toDate = new Date(dateRange.to)
        toDate.setHours(23, 59, 59, 999)
        matchesDateRange = paymentDate >= fromDate && paymentDate <= toDate
      } else {
        matchesDateRange = paymentDate.toDateString() === fromDate.toDateString()
      }
    }

    return matchesSearch && matchesStatus && matchesDateRange
  })

  return (
    <OwnerLayout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Payments</h1>
            <p className="text-gray-500">Manage and track all your payments</p>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search payments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Payments</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="refunded">Refunded</SelectItem>
            </SelectContent>
          </Select>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="justify-start text-left font-normal">
                <Calendar className="mr-2 h-4 w-4" />
                {dateRange?.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(dateRange.from, "LLL dd, y")
                  )
                ) : (
                  "Date Range"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                initialFocus
                mode="range"
                defaultMonth={dateRange?.from}
                selected={dateRange}
                onSelect={setDateRange}
                numberOfMonths={2}
              />
              <div className="flex items-center justify-between p-3 border-t">
                <Button variant="ghost" size="sm" onClick={() => setDateRange(undefined)}>
                  Clear
                </Button>
                <Button size="sm" onClick={() => document.body.click()}>
                  Apply
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          <Button className="bg-[#0A2647] hover:bg-[#0A2647]/90">
            <Download className="mr-2 h-4 w-4" />
            Export Payments
          </Button>
        </div>

        {/* Payments Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ₹{payments.reduce((sum, p) => sum + (p.status === "paid" ? p.amount : 0), 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">+20.1% from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-muted-foreground"
              >
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 16 14" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ₹{payments.reduce((sum, p) => sum + (p.status === "pending" ? p.amount : 0), 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                {payments.filter((p) => p.status === "pending").length} pending payments
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Refunded Amount</CardTitle>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-muted-foreground"
              >
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                <polyline points="9 22 9 12 15 12 15 22" />
              </svg>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ₹{payments.reduce((sum, p) => sum + (p.status === "refunded" ? p.amount : 0), 0).toLocaleString()}
              </div>
              <p className="text-xs text-muted-foreground">
                {payments.filter((p) => p.status === "refunded").length} refunded payments
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Payments Table */}
        <Card>
          <CardHeader>
            <CardTitle>Payment History</CardTitle>
            <CardDescription>A list of all payments for your listings</CardDescription>
          </CardHeader>
          <CardContent>
            <DataTable columns={columns} data={filteredPayments} />
          </CardContent>
        </Card>
      </div>
    </OwnerLayout>
  )
}

