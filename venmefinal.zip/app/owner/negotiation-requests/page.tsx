"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import OwnerLayout from "@/components/owner-layout"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"
import { Search, Calendar, Phone, Mail, CheckCircle2, XCircle, MessageSquare } from "lucide-react"

// Define the Negotiation Request type
interface NegotiationRequest {
  id: string
  listingId: string
  listingName: string
  customerName: string
  customerEmail: string
  customerPhone: string
  eventDate: string
  message: string
  status: "pending" | "accepted" | "rejected"
  ownerResponse?: string
  counterOffer?: number
  createdAt: string
}

export default function NegotiationRequestsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { isAuthenticated } = useOwnerAuth()
  const [mounted, setMounted] = useState(false)
  const [requests, setRequests] = useState<NegotiationRequest[]>([])
  const [filteredRequests, setFilteredRequests] = useState<NegotiationRequest[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRequest, setSelectedRequest] = useState<NegotiationRequest | null>(null)
  const [responseDialogOpen, setResponseDialogOpen] = useState(false)
  const [responseType, setResponseType] = useState<"accept" | "reject" | "counter">("accept")
  const [responseMessage, setResponseMessage] = useState("")
  const [counterOffer, setCounterOffer] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    setMounted(true)

    if (mounted && !isAuthenticated()) {
      router.push("/owner/login")
    }
  }, [mounted, isAuthenticated, router])

  useEffect(() => {
    // Mock data for negotiation requests
    const mockRequests: NegotiationRequest[] = [
      {
        id: "nr-001",
        listingId: "lotus-banquet",
        listingName: "The Grand Lotus Banquets",
        customerName: "Rahul Sharma",
        customerEmail: "rahul.sharma@example.com",
        customerPhone: "+91 98765 43210",
        eventDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
        message:
          "I'm interested in booking this venue for a wedding with 300 guests. My budget is ₹65,000. I would also like to know if you can arrange decoration and catering within this budget.",
        status: "pending",
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
      },
      {
        id: "nr-002",
        listingId: "lotus-banquet",
        listingName: "The Grand Lotus Banquets",
        customerName: "Priya Patel",
        customerEmail: "priya.patel@example.com",
        customerPhone: "+91 87654 32109",
        eventDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString(), // 45 days from now
        message:
          "Hello, I'm planning a corporate event for about 150 people. Can you offer a special rate for weekday booking? Our budget is around ₹60,000 including basic catering.",
        status: "pending",
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
      },
      {
        id: "nr-003",
        listingId: "lotus-banquet",
        listingName: "The Grand Lotus Banquets",
        customerName: "Amit Kumar",
        customerEmail: "amit.kumar@example.com",
        customerPhone: "+91 76543 21098",
        eventDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString(), // 60 days from now
        message:
          "I'm looking to book your venue for a birthday party. The standard rate is a bit out of my budget. Can we negotiate on the price? I would need basic decoration only.",
        status: "accepted",
        ownerResponse:
          "We would be happy to accommodate your birthday party! We can offer a 10% discount on our standard rate for weekday bookings.",
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), // 5 days ago
      },
      {
        id: "nr-004",
        listingId: "lotus-banquet",
        listingName: "The Grand Lotus Banquets",
        customerName: "Neha Gupta",
        customerEmail: "neha.gupta@example.com",
        customerPhone: "+91 65432 10987",
        eventDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days from now
        message:
          "We're planning an engagement ceremony for about 200 guests. Our budget is ₹55,000. Can you please let me know if this is possible? We need decoration and basic catering.",
        status: "rejected",
        ownerResponse:
          "We appreciate your interest in our venue. Unfortunately, we cannot accommodate your budget for the services requested. Our minimum package for 200 guests starts at ₹65,000.",
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
      },
      {
        id: "nr-005",
        listingId: "lotus-banquet",
        listingName: "The Grand Lotus Banquets",
        customerName: "Vikram Singh",
        customerEmail: "vikram.singh@example.com",
        customerPhone: "+91 54321 09876",
        eventDate: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000).toISOString(), // 120 days from now
        message:
          "Hi, I'm interested in booking your venue for a corporate event. Can you provide a discount for a weekday booking? Also, do you offer a package that includes projector and sound system?",
        status: "accepted",
        counterOffer: 68000,
        ownerResponse:
          "Thank you for your interest. We can offer a special weekday rate of ₹68,000 which includes projector, sound system, and basic catering for up to 150 guests.",
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days ago
      },
    ]

    setRequests(mockRequests)
    setFilteredRequests(mockRequests)
  }, [mounted])

  useEffect(() => {
    // Filter requests based on search query
    if (searchQuery) {
      const filtered = requests.filter(
        (request) =>
          request.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          request.customerEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
          request.listingName.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setFilteredRequests(filtered)
    } else {
      setFilteredRequests(requests)
    }
  }, [searchQuery, requests])

  if (!mounted || !isAuthenticated()) {
    return null
  }

  const handleOpenResponseDialog = (request: NegotiationRequest, type: "accept" | "reject" | "counter") => {
    setSelectedRequest(request)
    setResponseType(type)
    setResponseMessage("")
    setCounterOffer("")
    setResponseDialogOpen(true)
  }

  const handleSubmitResponse = () => {
    if (!selectedRequest) return

    setIsSubmitting(true)

    // Validate form
    if (responseType === "counter" && (!counterOffer || isNaN(Number(counterOffer)))) {
      toast({
        title: "Missing information",
        description: "Please enter a valid counter offer amount.",
        variant: "destructive",
      })
      setIsSubmitting(false)
      return
    }

    if (!responseMessage) {
      toast({
        title: "Missing information",
        description: "Please enter a response message.",
        variant: "destructive",
      })
      setIsSubmitting(false)
      return
    }

    // Simulate API call
    setTimeout(() => {
      // Update the request with the response
      const updatedRequests = requests.map((req) => {
        if (req.id === selectedRequest.id) {
          return {
            ...req,
            status: responseType === "counter" ? "accepted" : responseType,
            ownerResponse: responseMessage,
            ...(responseType === "counter" && { counterOffer: Number(counterOffer) }),
          }
        }
        return req
      })

      setRequests(updatedRequests)
      setFilteredRequests(updatedRequests)
      setIsSubmitting(false)
      setResponseDialogOpen(false)

      toast({
        title: "Response sent",
        description: `Your response to ${selectedRequest.customerName} has been sent successfully.`,
      })
    }, 1500)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "accepted":
        return <Badge className="bg-green-500">Accepted</Badge>
      case "rejected":
        return <Badge className="bg-red-500">Rejected</Badge>
      case "pending":
        return <Badge className="bg-amber-500">Pending</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  return (
    <OwnerLayout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Negotiation Requests</h1>
            <p className="text-gray-500">Manage price negotiation requests from potential customers</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Tabs */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList>
            <TabsTrigger value="all" className="flex items-center gap-1">
              All
              <Badge variant="outline" className="ml-1">
                {requests.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="pending" className="flex items-center gap-1">
              Pending
              <Badge variant="outline" className="ml-1">
                {requests.filter((r) => r.status === "pending").length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="accepted" className="flex items-center gap-1">
              Accepted
              <Badge variant="outline" className="ml-1">
                {requests.filter((r) => r.status === "accepted").length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="rejected" className="flex items-center gap-1">
              Rejected
              <Badge variant="outline" className="ml-1">
                {requests.filter((r) => r.status === "rejected").length}
              </Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">{renderRequestList(filteredRequests)}</TabsContent>

          <TabsContent value="pending">
            {renderRequestList(filteredRequests.filter((r) => r.status === "pending"))}
          </TabsContent>

          <TabsContent value="accepted">
            {renderRequestList(filteredRequests.filter((r) => r.status === "accepted"))}
          </TabsContent>

          <TabsContent value="rejected">
            {renderRequestList(filteredRequests.filter((r) => r.status === "rejected"))}
          </TabsContent>
        </Tabs>
      </div>

      {/* Response Dialog */}
      <Dialog open={responseDialogOpen} onOpenChange={setResponseDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              {responseType === "accept"
                ? "Accept Request"
                : responseType === "reject"
                  ? "Reject Request"
                  : "Send Counter Offer"}
            </DialogTitle>
            <DialogDescription>
              {responseType === "accept"
                ? "Accept this negotiation request and send a message to the customer."
                : responseType === "reject"
                  ? "Reject this negotiation request and provide a reason to the customer."
                  : "Send a counter offer with your price and terms."}
            </DialogDescription>
          </DialogHeader>

          {selectedRequest && (
            <div className="py-4">
              <div className="mb-4 bg-accent/10 p-3 rounded-md">
                <p className="font-semibold">Request from {selectedRequest.customerName}</p>
                <p className="text-sm text-gray-500">
                  {format(new Date(selectedRequest.eventDate), "PPP")} | {selectedRequest.listingName}
                </p>
                <p className="mt-2 text-sm">{selectedRequest.message}</p>
              </div>

              {responseType === "counter" && (
                <div className="mb-4">
                  <Label htmlFor="counter-offer">Counter Offer Amount (₹)</Label>
                  <Input
                    id="counter-offer"
                    type="number"
                    value={counterOffer}
                    onChange={(e) => setCounterOffer(e.target.value)}
                    placeholder="e.g., 65000"
                    className="mt-1"
                  />
                </div>
              )}

              <div>
                <Label htmlFor="response-message">Your Response</Label>
                <Textarea
                  id="response-message"
                  value={responseMessage}
                  onChange={(e) => setResponseMessage(e.target.value)}
                  placeholder={
                    responseType === "accept"
                      ? "Thank you for your interest. We are happy to accept your request..."
                      : responseType === "reject"
                        ? "Thank you for your interest. Unfortunately, we cannot accommodate..."
                        : "Thank you for your interest. We can offer a rate of ₹..."
                  }
                  className="mt-1 min-h-[100px]"
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setResponseDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSubmitResponse}
              className={
                responseType === "accept"
                  ? "bg-green-600 hover:bg-green-700"
                  : responseType === "reject"
                    ? "bg-red-600 hover:bg-red-700"
                    : "bg-primary hover:bg-primary/90"
              }
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  Sending...
                </>
              ) : responseType === "accept" ? (
                "Accept & Send"
              ) : responseType === "reject" ? (
                "Reject & Send"
              ) : (
                "Send Counter Offer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </OwnerLayout>
  )

  function renderRequestList(requests: NegotiationRequest[]) {
    if (requests.length === 0) {
      return (
        <div className="text-center py-12">
          <MessageSquare className="h-12 w-12 mx-auto text-gray-300" />
          <h3 className="mt-4 text-lg font-medium">No negotiation requests found</h3>
          <p className="mt-1 text-gray-500">
            {searchQuery ? "Try adjusting your search" : "You don't have any negotiation requests yet"}
          </p>
        </div>
      )
    }

    return (
      <div className="space-y-4 mt-4">
        {requests.map((request) => (
          <Card key={request.id}>
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <CardTitle className="text-lg">{request.customerName}</CardTitle>
                {getStatusBadge(request.status)}
              </div>
              <CardDescription>For {request.listingName}</CardDescription>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="flex items-center text-sm">
                  <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                  <span>Event: {format(new Date(request.eventDate), "PPP")}</span>
                </div>
                <div className="flex items-center text-sm">
                  <Mail className="h-4 w-4 mr-2 text-gray-500" />
                  <span>{request.customerEmail}</span>
                </div>
                <div className="flex items-center text-sm">
                  <Phone className="h-4 w-4 mr-2 text-gray-500" />
                  <span>{request.customerPhone}</span>
                </div>
              </div>

              <div className="bg-gray-50 p-3 rounded-md">
                <p className="text-sm">{request.message}</p>
              </div>

              {request.status !== "pending" && (
                <div className="mt-3 pt-3 border-t">
                  <p className="text-sm font-medium">Your Response:</p>
                  <p className="text-sm mt-1">{request.ownerResponse}</p>
                  {request.counterOffer && (
                    <p className="text-sm mt-1 font-medium">Counter offer: ₹{request.counterOffer.toLocaleString()}</p>
                  )}
                </div>
              )}
            </CardContent>
            {request.status === "pending" && (
              <CardFooter className="pt-0">
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-green-500 text-green-600 hover:bg-green-50"
                    onClick={() => handleOpenResponseDialog(request, "accept")}
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Accept
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-primary text-primary hover:bg-primary/10"
                    onClick={() => handleOpenResponseDialog(request, "counter")}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Counter Offer
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-red-500 text-red-600 hover:bg-red-50"
                    onClick={() => handleOpenResponseDialog(request, "reject")}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Reject
                  </Button>
                </div>
              </CardFooter>
            )}
          </Card>
        ))}
      </div>
    )
  }
}

