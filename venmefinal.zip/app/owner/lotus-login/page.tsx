"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, EyeOff, ArrowRight } from "lucide-react"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"

export default function LotusOwnerLoginPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { login } = useOwnerAuth()

  // Login state
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoggingIn, setIsLoggingIn] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()

    setIsLoggingIn(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // For demo purposes, we'll accept any login for The Grand Lotus Banquets
      if (email.includes("lotus") || email === "admin@grandlotus.com") {
        toast({
          title: "Login successful",
          description: "Welcome back to The Grand Lotus Banquets dashboard.",
        })
        router.push("/owner/dashboard")
      } else {
        toast({
          title: "Login failed",
          description: "Invalid credentials for The Grand Lotus Banquets.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Login failed",
        description: "An error occurred. Please try again later.",
        variant: "destructive",
      })
    } finally {
      setIsLoggingIn(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Left side - Image */}
        <div className="hidden md:flex md:w-1/2 bg-[#213555] relative">
          <div className="absolute inset-0 flex flex-col justify-center items-center text-white p-12">
            <div className="max-w-md">
              <h1 className="text-3xl font-bold mb-6">The Grand Lotus Banquets</h1>
              <p className="text-lg mb-8">
                Manage your luxury venue, track bookings, and provide exceptional service to your clients.
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Exclusive Dashboard</h3>
                  <p className="text-sm">Manage your venue with our specialized tools</p>
                </div>
                <div className="bg-white/10 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Client Management</h3>
                  <p className="text-sm">Track and manage all client interactions</p>
                </div>
                <div className="bg-white/10 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Event Calendar</h3>
                  <p className="text-sm">Visualize your upcoming events</p>
                </div>
                <div className="bg-white/10 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Revenue Analytics</h3>
                  <p className="text-sm">Track your business performance</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Login form */}
        <div className="w-full md:w-1/2 flex items-center justify-center p-6">
          <div className="w-full max-w-md">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div className="relative w-24 h-24 overflow-hidden rounded-full border-4 border-[#D8C4B6]">
                  <Image
                    src="https://media-hosting.imagekit.io//c5be07ec0c524a4e/6.png?Expires=1836277614&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=yztd~KJO1f42IurYUBHJ9aWp2HRtxvD9asSubAsDOgRNm2Ac5T5QY2lJz0YOAP78Q9G8cE2uHuJ1k3aodxF5vac6Yh0pIvlnBkKqoExm3mCqBdOPVzzm1AfFLOUMKAE2TAUa38UangXbVvVPnIYVMD3zyDrMXbqoWODa9geRAVNj~izEGAjHCDhp6uNt9NHOH1myg8pEzghPkgXXuA6zzU1j5mSCOSFUL9UVMdRBNTvXWuhzercPv6o0rnAUQsifjSkVnU7KysJPti7i5kXfpVr6BOqOUuFLUqO6c8VG9Bx0lP0-x2ZtYtSDdyg81AfDZ6MvcIlcehX0HjRq7i-nIg__"
                    alt="The Grand Lotus Banquets Logo"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
              <h2 className="text-2xl font-bold">The Grand Lotus Banquets</h2>
              <p className="text-gray-500 mt-2">Owner Portal</p>
            </div>

            <Card>
              <form onSubmit={handleLogin}>
                <CardHeader>
                  <CardTitle>Login to your account</CardTitle>
                  <CardDescription>Enter your credentials to access your dashboard</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="admin@grandlotus.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-500" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-500" />
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex flex-col">
                  <Button type="submit" className="w-full bg-[#213555] hover:bg-[#213555]/90" disabled={isLoggingIn}>
                    {isLoggingIn ? (
                      <>
                        <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        Logging in...
                      </>
                    ) : (
                      <>
                        Login
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="link"
                    className="mt-2 text-sm"
                    onClick={() => {
                      // Demo credentials
                      setEmail("admin@grandlotus.com")
                      setPassword("lotus123")
                    }}
                  >
                    Use demo account
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

