"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"
import { useOwnerListings } from "@/lib/hooks/use-owner-listings"
import { useOwnerBookings } from "@/lib/hooks/use-owner-bookings"
import OwnerLayout from "@/components/owner-layout"
import {
  Calendar,
  DollarSign,
  MapPin,
  Plus,
  Users,
  ArrowRight,
  ArrowUpRight,
  Building,
  CheckCircle,
  Clock,
  XCircle,
} from "lucide-react"
import { ChartContainer } from "@/components/ui/chart"
import { Bar, Line, Pie } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import { formatDistanceToNow } from "date-fns"

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend)

export default function OwnerDashboardPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { owner, isAuthenticated } = useOwnerAuth()
  const { listings } = useOwnerListings()
  const { bookings } = useOwnerBookings()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    if (mounted && !isAuthenticated()) {
      router.push("/owner/login")
    }
  }, [mounted, isAuthenticated, router])

  if (!mounted || !isAuthenticated()) {
    return null
  }

  // Calculate dashboard metrics
  const totalListings = listings.length
  const activeListings = listings.filter((listing) => listing.active).length

  const totalBookings = bookings.length
  const confirmedBookings = bookings.filter((booking) => booking.status === "confirmed").length
  const pendingBookings = bookings.filter((booking) => booking.status === "pending").length
  const cancelledBookings = bookings.filter((booking) => booking.status === "cancelled").length

  const totalRevenue = bookings
    .filter((booking) => booking.status === "confirmed")
    .reduce((sum, booking) => sum + booking.amount, 0)

  const upcomingBookings = bookings
    .filter((booking) => {
      const bookingDate = new Date(booking.date)
      const today = new Date()
      return bookingDate > today && booking.status === "confirmed"
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5)

  const recentBookings = [...bookings]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5)

  // Chart data
  const bookingsByMonthData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    datasets: [
      {
        label: "Bookings",
        data: [5, 8, 12, 15, 10, 18, 20, 25, 22, 30, 28, 32],
        backgroundColor: "#0A2647",
        borderColor: "#0A2647",
      },
    ],
  }

  const revenueByMonthData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    datasets: [
      {
        label: "Revenue (₹)",
        data: [50000, 80000, 120000, 150000, 100000, 180000, 200000, 250000, 220000, 300000, 280000, 320000],
        backgroundColor: "rgba(10, 38, 71, 0.2)",
        borderColor: "#0A2647",
        tension: 0.4,
        fill: true,
      },
    ],
  }

  const bookingStatusData = {
    labels: ["Confirmed", "Pending", "Cancelled"],
    datasets: [
      {
        data: [confirmedBookings, pendingBookings, cancelledBookings],
        backgroundColor: ["#4CAF50", "#FFC107", "#F44336"],
        borderWidth: 1,
      },
    ],
  }

  return (
    <OwnerLayout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Welcome back, {owner?.name}</h1>
            <p className="text-gray-500">Here's what's happening with your party plots today.</p>
          </div>
          <Button onClick={() => router.push("/owner/listings/new")} className="bg-[#0A2647] hover:bg-[#0A2647]/90">
            <Plus className="mr-2 h-4 w-4" />
            Add New Listing
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Revenue</p>
                  <h3 className="text-2xl font-bold">₹{totalRevenue.toLocaleString()}</h3>
                </div>
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-gray-500">
                <ArrowUpRight className="h-4 w-4 mr-1 text-green-500" />
                <span className="text-green-500 font-medium">12%</span>
                <span className="ml-1">from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Bookings</p>
                  <h3 className="text-2xl font-bold">{totalBookings}</h3>
                </div>
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-gray-500">
                <ArrowUpRight className="h-4 w-4 mr-1 text-green-500" />
                <span className="text-green-500 font-medium">8%</span>
                <span className="ml-1">from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Active Listings</p>
                  <h3 className="text-2xl font-bold">{activeListings}</h3>
                </div>
                <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center">
                  <Building className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-gray-500">
                <span>Out of {totalListings} total listings</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Pending Bookings</p>
                  <h3 className="text-2xl font-bold">{pendingBookings}</h3>
                </div>
                <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-amber-600" />
                </div>
              </div>
              <div className="mt-4">
                <Button
                  variant="link"
                  className="p-0 h-auto text-sm text-[#0A2647]"
                  onClick={() => router.push("/owner/bookings")}
                >
                  View pending requests
                  <ArrowRight className="ml-1 h-3 w-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Bookings Overview</CardTitle>
              <CardDescription>Monthly booking trends for the current year</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ChartContainer>
                  <Bar
                    data={bookingsByMonthData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      scales: {
                        y: {
                          beginAtZero: true,
                          ticks: {
                            precision: 0,
                          },
                        },
                      },
                    }}
                  />
                </ChartContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Revenue Overview</CardTitle>
              <CardDescription>Monthly revenue trends for the current year</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ChartContainer>
                  <Line
                    data={revenueByMonthData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      scales: {
                        y: {
                          beginAtZero: true,
                        },
                      },
                    }}
                  />
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Booking Status and Upcoming Bookings */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Booking Status</CardTitle>
              <CardDescription>Distribution of booking statuses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center">
                <ChartContainer className="max-w-xs">
                  <Pie
                    data={bookingStatusData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          position: "bottom",
                        },
                      },
                    }}
                  />
                </ChartContainer>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">{confirmedBookings}</div>
                  <div className="text-xs text-gray-500">Confirmed</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-amber-500">{pendingBookings}</div>
                  <div className="text-xs text-gray-500">Pending</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-500">{cancelledBookings}</div>
                  <div className="text-xs text-gray-500">Cancelled</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Upcoming Bookings</CardTitle>
                <CardDescription>Your next scheduled events</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => router.push("/owner/bookings")}>
                View All
              </Button>
            </CardHeader>
            <CardContent>
              {upcomingBookings.length > 0 ? (
                <div className="space-y-4">
                  {upcomingBookings.map((booking) => (
                    <div key={booking.id} className="flex items-center gap-4 p-3 rounded-lg border">
                      <div className="flex-shrink-0 h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                        <Calendar className="h-6 w-6 text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{booking.plotName}</p>
                        <p className="text-xs text-gray-500">
                          <span className="inline-flex items-center">
                            <MapPin className="h-3 w-3 mr-1" />
                            {booking.location}
                          </span>
                        </p>
                        <p className="text-xs text-gray-500">
                          <span className="inline-flex items-center">
                            <Users className="h-3 w-3 mr-1" />
                            {booking.customerName}
                          </span>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{new Date(booking.date).toLocaleDateString()}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(booking.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                        <p className="text-xs font-medium text-green-600">₹{booking.amount.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <Calendar className="h-12 w-12 mx-auto text-gray-300" />
                  <p className="mt-2 text-gray-500">No upcoming bookings</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest bookings and updates</CardDescription>
          </CardHeader>
          <CardContent>
            {recentBookings.length > 0 ? (
              <div className="space-y-4">
                {recentBookings.map((booking) => (
                  <div key={booking.id} className="flex items-start gap-4">
                    <div
                      className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                        booking.status === "confirmed"
                          ? "bg-green-100"
                          : booking.status === "pending"
                            ? "bg-amber-100"
                            : "bg-red-100"
                      }`}
                    >
                      {booking.status === "confirmed" ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : booking.status === "pending" ? (
                        <Clock className="h-5 w-5 text-amber-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm">
                        <span className="font-medium">{booking.customerName}</span>{" "}
                        {booking.status === "confirmed"
                          ? "booked"
                          : booking.status === "pending"
                            ? "requested to book"
                            : "cancelled booking for"}{" "}
                        <span className="font-medium">{booking.plotName}</span>
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(booking.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                    {booking.status === "pending" && (
                      <div className="flex-shrink-0">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => router.push(`/owner/bookings/${booking.id}`)}
                        >
                          Review
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-gray-500">No recent activity</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Negotiation Requests */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Negotiation Requests</CardTitle>
              <CardDescription>Latest price negotiation requests from customers</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => router.push("/owner/negotiation-requests")}>
              View All
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Sample negotiation requests */}
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 flex items-center justify-center h-10 w-10 rounded-full bg-amber-100">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">
                    <span className="font-medium">Rahul Sharma</span> sent a negotiation request for{" "}
                    <span className="font-medium">The Grand Lotus Banquets</span>
                  </p>
                  <p className="text-xs text-gray-500">2 days ago</p>
                </div>
                <div className="flex-shrink-0">
                  <Button variant="outline" size="sm" onClick={() => router.push("/owner/negotiation-requests")}>
                    Review
                  </Button>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 flex items-center justify-center h-10 w-10 rounded-full bg-amber-100">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">
                    <span className="font-medium">Priya Patel</span> sent a negotiation request for{" "}
                    <span className="font-medium">The Grand Lotus Banquets</span>
                  </p>
                  <p className="text-xs text-gray-500">1 day ago</p>
                </div>
                <div className="flex-shrink-0">
                  <Button variant="outline" size="sm" onClick={() => router.push("/owner/negotiation-requests")}>
                    Review
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </OwnerLayout>
  )
}

