"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"
import { useOwnerListings } from "@/lib/hooks/use-owner-listings"
import OwnerLayout from "@/components/owner-layout"
import { ArrowLeft, Upload } from "lucide-react"
import Image from "next/image"

export default function NewListingPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { isAuthenticated } = useOwnerAuth()
  const { addListing } = useOwnerListings()
  const [mounted, setMounted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Form state
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [location, setLocation] = useState("")
  const [price, setPrice] = useState("")
  const [capacity, setCapacity] = useState("")
  const [amenities, setAmenities] = useState({
    parking: false,
    catering: false,
    decoration: false,
    sound: false,
    wifi: false,
    ac: false,
    power: false,
    security: false,
  })
  const [image, setImage] = useState<string | null>(null)
  const [previewImage, setPreviewImage] = useState<string | null>(null)

  useEffect(() => {
    setMounted(true)

    if (mounted && !isAuthenticated()) {
      router.push("/owner/login")
    }
  }, [mounted, isAuthenticated, router])

  if (!mounted || !isAuthenticated()) {
    return null
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // In a real app, you would upload this to a server
      // For now, we'll just create a local URL
      const imageUrl = URL.createObjectURL(file)
      setPreviewImage(imageUrl)
      setImage("/placeholder.svg?height=400&width=600") // In real app, this would be the uploaded image URL
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!name.trim()) {
      toast({
        title: "Name required",
        description: "Please enter a name for your listing.",
        variant: "destructive",
      })
      return
    }

    if (!location.trim()) {
      toast({
        title: "Location required",
        description: "Please enter a location for your listing.",
        variant: "destructive",
      })
      return
    }

    const priceValue = Number.parseFloat(price)
    if (isNaN(priceValue) || priceValue <= 0) {
      toast({
        title: "Invalid price",
        description: "Please enter a valid price for your listing.",
        variant: "destructive",
      })
      return
    }

    const capacityValue = Number.parseInt(capacity)
    if (isNaN(capacityValue) || capacityValue <= 0) {
      toast({
        title: "Invalid capacity",
        description: "Please enter a valid capacity for your listing.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Prepare listing data
      const selectedAmenities = Object.entries(amenities)
        .filter(([_, selected]) => selected)
        .map(([name]) => name)

      // Add listing
      const newListing = {
        name,
        description,
        location,
        price: priceValue,
        capacity: capacityValue,
        amenities: selectedAmenities,
        image: image || "/placeholder.svg?height=400&width=600",
        active: true,
        createdAt: new Date().toISOString(),
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      addListing(newListing)

      toast({
        title: "Listing created",
        description: "Your new listing has been created successfully.",
      })

      router.push("/owner/listings")
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while creating your listing. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <OwnerLayout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-3xl font-bold">Add New Listing</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Basic Information</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Listing Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Royal Garden Party Plot"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location *</Label>
                <Input
                  id="location"
                  placeholder="e.g., Mumbai, Maharashtra"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe your party plot..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
              />
            </div>
          </div>

          {/* Pricing and Capacity */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Pricing and Capacity</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Price per Day (₹) *</Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="e.g., 25000"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  min="0"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="capacity">Maximum Capacity *</Label>
                <Input
                  id="capacity"
                  type="number"
                  placeholder="e.g., 500"
                  value={capacity}
                  onChange={(e) => setCapacity(e.target.value)}
                  min="1"
                  required
                />
              </div>
            </div>
          </div>

          {/* Amenities */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Amenities</h2>
            <p className="text-sm text-gray-500">Select all amenities that your venue offers</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="parking"
                  checked={amenities.parking}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, parking: checked as boolean })}
                />
                <Label htmlFor="parking">Parking</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="catering"
                  checked={amenities.catering}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, catering: checked as boolean })}
                />
                <Label htmlFor="catering">Catering</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="decoration"
                  checked={amenities.decoration}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, decoration: checked as boolean })}
                />
                <Label htmlFor="decoration">Decoration</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="sound"
                  checked={amenities.sound}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, sound: checked as boolean })}
                />
                <Label htmlFor="sound">Sound System</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="wifi"
                  checked={amenities.wifi}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, wifi: checked as boolean })}
                />
                <Label htmlFor="wifi">WiFi</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="ac"
                  checked={amenities.ac}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, ac: checked as boolean })}
                />
                <Label htmlFor="ac">Air Conditioning</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="power"
                  checked={amenities.power}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, power: checked as boolean })}
                />
                <Label htmlFor="power">Backup Power</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="security"
                  checked={amenities.security}
                  onCheckedChange={(checked) => setAmenities({ ...amenities, security: checked as boolean })}
                />
                <Label htmlFor="security">Security</Label>
              </div>
            </div>
          </div>

          {/* Images */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Images</h2>
            <p className="text-sm text-gray-500">Upload high-quality images of your venue</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="image">Main Image</Label>
                <div className="border-2 border-dashed rounded-lg p-4 text-center">
                  <Input id="image" type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                  {previewImage ? (
                    <div className="relative h-48 w-full">
                      <Image
                        src={previewImage || "/placeholder.svg"}
                        alt="Preview"
                        fill
                        className="object-cover rounded-md"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="absolute bottom-2 right-2 bg-white"
                        onClick={() => {
                          setPreviewImage(null)
                          setImage(null)
                        }}
                      >
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <Label htmlFor="image" className="flex flex-col items-center justify-center h-48 cursor-pointer">
                      <Upload className="h-10 w-10 text-gray-300" />
                      <p className="mt-2 text-sm text-gray-500">Click to upload an image</p>
                      <p className="text-xs text-gray-400">PNG, JPG, GIF up to 10MB</p>
                    </Label>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Preview</Label>
                <div className="border rounded-lg p-4 h-48 flex items-center justify-center bg-gray-50">
                  {previewImage ? (
                    <div className="relative h-full w-full">
                      <Image src={previewImage || "/placeholder.svg"} alt="Preview" fill className="object-contain" />
                    </div>
                  ) : (
                    <p className="text-gray-400">Image preview will appear here</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit" className="bg-[#0A2647] hover:bg-[#0A2647]/90" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  Creating Listing...
                </>
              ) : (
                "Create Listing"
              )}
            </Button>
          </div>
        </form>
      </div>
    </OwnerLayout>
  )
}

