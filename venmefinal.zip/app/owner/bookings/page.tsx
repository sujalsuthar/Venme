"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { useOwnerAuth } from "@/lib/hooks/use-owner-auth"
import { useOwnerBookings } from "@/lib/hooks/use-owner-bookings"
import OwnerLayout from "@/components/owner-layout"
import { Calendar, CheckCircle, Clock, Download, Eye, MapPin, Search, XCircle } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import type { DateRange } from "react-day-picker"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

export default function OwnerBookingsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { isAuthenticated } = useOwnerAuth()
  const { bookings, updateBookingStatus } = useOwnerBookings()
  const [mounted, setMounted] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sortBy, setSortBy] = useState("newest")
  const [dateRange, setDateRange] = useState<DateRange | undefined>()

  useEffect(() => {
    setMounted(true)

    if (mounted && !isAuthenticated()) {
      router.push("/owner/login")
    }
  }, [mounted, isAuthenticated, router])

  if (!mounted || !isAuthenticated()) {
    return null
  }

  // Filter and sort bookings
  const filteredBookings = bookings.filter((booking) => {
    // Apply search filter
    const matchesSearch =
      booking.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.plotName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      booking.location.toLowerCase().includes(searchQuery.toLowerCase())

    // Apply status filter
    const matchesStatus = statusFilter === "all" || booking.status === statusFilter

    // Apply date range filter
    let matchesDateRange = true
    if (dateRange?.from) {
      const bookingDate = new Date(booking.date)
      const fromDate = new Date(dateRange.from)
      fromDate.setHours(0, 0, 0, 0)

      if (dateRange.to) {
        const toDate = new Date(dateRange.to)
        toDate.setHours(23, 59, 59, 999)
        matchesDateRange = bookingDate >= fromDate && bookingDate <= toDate
      } else {
        matchesDateRange = bookingDate.toDateString() === fromDate.toDateString()
      }
    }

    return matchesSearch && matchesStatus && matchesDateRange
  })

  // Sort bookings
  const sortedBookings = [...filteredBookings].sort((a, b) => {
    switch (sortBy) {
      case "newest":
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      case "oldest":
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      case "date-asc":
        return new Date(a.date).getTime() - new Date(b.date).getTime()
      case "date-desc":
        return new Date(b.date).getTime() - new Date(a.date).getTime()
      case "amount-high":
        return b.amount - a.amount
      case "amount-low":
        return a.amount - b.amount
      default:
        return 0
    }
  })

  const handleAcceptBooking = (id: string) => {
    updateBookingStatus(id, "confirmed")
    toast({
      title: "Booking confirmed",
      description: "The booking has been confirmed successfully.",
    })
  }

  const handleRejectBooking = (id: string) => {
    updateBookingStatus(id, "cancelled")
    toast({
      title: "Booking cancelled",
      description: "The booking has been cancelled successfully.",
    })
  }

  const handleGenerateInvoice = (booking: any) => {
    // In a real app, this would generate and download a PDF invoice
    toast({
      title: "Invoice generated",
      description: `Invoice for ${booking.customerName} has been generated.`,
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-green-500">Confirmed</Badge>
      case "pending":
        return <Badge className="bg-amber-500">Pending</Badge>
      case "cancelled":
        return <Badge className="bg-red-500">Cancelled</Badge>
      default:
        return <Badge>Unknown</Badge>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmed":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "pending":
        return <Clock className="h-5 w-5 text-amber-500" />
      case "cancelled":
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return null
    }
  }

  return (
    <OwnerLayout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">Bookings</h1>
            <p className="text-gray-500">Manage all your party plot bookings</p>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search bookings..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Bookings</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="justify-start text-left font-normal">
                <Calendar className="mr-2 h-4 w-4" />
                {dateRange?.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                    </>
                  ) : (
                    format(dateRange.from, "LLL dd, y")
                  )
                ) : (
                  "Date Range"
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                initialFocus
                mode="range"
                defaultMonth={dateRange?.from}
                selected={dateRange}
                onSelect={setDateRange}
                numberOfMonths={2}
              />
              <div className="flex items-center justify-between p-3 border-t">
                <Button variant="ghost" size="sm" onClick={() => setDateRange(undefined)}>
                  Clear
                </Button>
                <Button size="sm" onClick={() => document.body.click()}>
                  Apply
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger>
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="date-asc">Event Date (Ascending)</SelectItem>
              <SelectItem value="date-desc">Event Date (Descending)</SelectItem>
              <SelectItem value="amount-high">Amount (High to Low)</SelectItem>
              <SelectItem value="amount-low">Amount (Low to High)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Bookings */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList>
            <TabsTrigger value="all" className="flex items-center gap-1">
              All
              <Badge variant="outline" className="ml-1">
                {bookings.length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="pending" className="flex items-center gap-1">
              Pending
              <Badge variant="outline" className="ml-1">
                {bookings.filter((b) => b.status === "pending").length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="confirmed" className="flex items-center gap-1">
              Confirmed
              <Badge variant="outline" className="ml-1">
                {bookings.filter((b) => b.status === "confirmed").length}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="cancelled" className="flex items-center gap-1">
              Cancelled
              <Badge variant="outline" className="ml-1">
                {bookings.filter((b) => b.status === "cancelled").length}
              </Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">{renderBookingsList(sortedBookings)}</TabsContent>

          <TabsContent value="pending">
            {renderBookingsList(sortedBookings.filter((b) => b.status === "pending"))}
          </TabsContent>

          <TabsContent value="confirmed">
            {renderBookingsList(sortedBookings.filter((b) => b.status === "confirmed"))}
          </TabsContent>

          <TabsContent value="cancelled">
            {renderBookingsList(sortedBookings.filter((b) => b.status === "cancelled"))}
          </TabsContent>
        </Tabs>
      </div>
    </OwnerLayout>
  )

  function renderBookingsList(bookings: any[]) {
    if (bookings.length === 0) {
      return (
        <div className="text-center py-12">
          <Calendar className="h-12 w-12 mx-auto text-gray-300" />
          <h3 className="mt-4 text-lg font-medium">No bookings found</h3>
          <p className="mt-1 text-gray-500">
            {statusFilter !== "all" || dateRange?.from || searchQuery
              ? "Try adjusting your filters"
              : "You don't have any bookings yet"}
          </p>
        </div>
      )
    }

    return (
      <div className="space-y-4">
        {bookings.map((booking) => (
          <Card key={booking.id}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-gray-100">
                  {getStatusIcon(booking.status)}
                </div>

                <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <h3 className="text-lg font-semibold">{booking.plotName}</h3>
                    <p className="text-gray-500 flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {booking.location}
                    </p>
                    <div className="mt-2">{getStatusBadge(booking.status)}</div>
                  </div>

                  <div>
                    <p className="text-sm font-medium">Customer</p>
                    <p className="text-gray-900">{booking.customerName}</p>
                    <p className="text-gray-500">{booking.customerEmail}</p>
                    <p className="text-gray-500">{booking.customerPhone}</p>
                  </div>

                  <div>
                    <p className="text-sm font-medium">Event Details</p>
                    <p className="text-gray-900 flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {new Date(booking.date).toLocaleDateString()}
                    </p>
                    <p className="text-gray-500">
                      {new Date(booking.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                    <p className="text-gray-900 font-semibold mt-1">₹{booking.amount.toLocaleString()}</p>
                  </div>
                </div>

                <div className="flex flex-row md:flex-col gap-2 justify-end">
                  <Button variant="outline" size="sm" onClick={() => router.push(`/owner/bookings/${booking.id}`)}>
                    <Eye className="h-4 w-4 mr-2" />
                    View
                  </Button>

                  {booking.status === "pending" && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        className="bg-green-50 text-green-600 border-green-200 hover:bg-green-100"
                        onClick={() => handleAcceptBooking(booking.id)}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Accept
                      </Button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            className="bg-red-50 text-red-600 border-red-200 hover:bg-red-100"
                          >
                            <XCircle className="h-4 w-4 mr-2" />
                            Reject
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will cancel the booking request. The customer will be notified.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleRejectBooking(booking.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Reject Booking
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </>
                  )}

                  {booking.status === "confirmed" && (
                    <Button variant="outline" size="sm" onClick={() => handleGenerateInvoice(booking)}>
                      <Download className="h-4 w-4 mr-2" />
                      Invoice
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }
}

