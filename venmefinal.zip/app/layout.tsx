import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { Toaster } from "@/components/ui/toaster"
import ScrollToTop from "@/components/scroll-to-top"
import { CartProvider } from "@/lib/providers/cart-provider"
import { WatchlistProvider } from "@/lib/providers/watchlist-provider"
import { RecentlyViewedProvider } from "@/lib/providers/recently-viewed-provider"
import { FavoritesProvider } from "@/lib/providers/favorites-provider"
import { BookingsProvider } from "@/lib/providers/bookings-provider"
import { ThemeProvider } from "@/components/theme-provider"
import { OwnerAuthProvider } from "@/lib/hooks/use-owner-auth"
import { OwnerListingsProvider } from "@/lib/hooks/use-owner-listings"
import { OwnerBookingsProvider } from "@/lib/hooks/use-owner-bookings"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Venme - Premium Venue Booking Platform",
  description: "Book the perfect venue for your next event with Venme",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          <OwnerAuthProvider>
            <OwnerListingsProvider>
              <OwnerBookingsProvider>
                <CartProvider>
                  <WatchlistProvider>
                    <RecentlyViewedProvider>
                      <FavoritesProvider>
                        <BookingsProvider>
                          <Navbar />
                          <main className="min-h-screen pt-16">{children}</main>
                          <Footer />
                          <Toaster />
                          <ScrollToTop />
                        </BookingsProvider>
                      </FavoritesProvider>
                    </RecentlyViewedProvider>
                  </WatchlistProvider>
                </CartProvider>
              </OwnerBookingsProvider>
            </OwnerListingsProvider>
          </OwnerAuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'