"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Eye, EyeOff, User, Building } from "lucide-react"
import Image from "next/image"
import OtpVerification from "@/components/otp-verification"

export default function LoginPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("customer")

  // Customer login state
  const [customerEmail, setCustomerEmail] = useState("")
  const [customerPassword, setCustomerPassword] = useState("")
  const [showCustomerPassword, setShowCustomerPassword] = useState(false)

  // Owner login state
  const [ownerEmail, setOwnerEmail] = useState("")
  const [ownerPassword, setOwnerPassword] = useState("")
  const [showOwnerPassword, setShowOwnerPassword] = useState(false)

  // OTP verification state
  const [showOtp, setShowOtp] = useState(false)
  const [otpEmail, setOtpEmail] = useState("")
  const [otpType, setOtpType] = useState<"customer" | "owner">("customer")

  const handleCustomerLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (!customerEmail || !customerPassword) {
      toast({
        title: "Error",
        description: "Please enter both email and password",
        variant: "destructive",
      })
      return
    }

    // Simulate login validation
    if (customerEmail === "customer@example.com" && customerPassword === "password") {
      setOtpEmail(customerEmail)
      setOtpType("customer")
      setShowOtp(true)
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid email or password. Try customer@example.com / password",
        variant: "destructive",
      })
    }
  }

  const handleOwnerLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (!ownerEmail || !ownerPassword) {
      toast({
        title: "Error",
        description: "Please enter both email and password",
        variant: "destructive",
      })
      return
    }

    // Simulate login validation
    if (ownerEmail === "owner@example.com" && ownerPassword === "password") {
      setOtpEmail(ownerEmail)
      setOtpType("owner")
      setShowOtp(true)
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid email or password. Try owner@example.com / password",
        variant: "destructive",
      })
    }
  }

  const handleOtpVerified = () => {
    toast({
      title: "Login Successful",
      description: `Welcome back! You've been logged in as ${otpType === "customer" ? "a customer" : "an owner"}.`,
    })

    // Redirect based on user type
    if (otpType === "customer") {
      router.push("/")
    } else {
      router.push("/owner/dashboard")
    }
  }

  if (showOtp) {
    return <OtpVerification email={otpEmail} onVerified={handleOtpVerified} onCancel={() => setShowOtp(false)} />
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left side - Image and branding */}
      <div className="md:w-1/2 bg-primary p-8 flex flex-col justify-center items-center text-primary-foreground">
        <div className="max-w-md text-center">
          <h1 className="text-4xl font-bold mb-4">Party Plot Rental</h1>
          <p className="text-xl mb-8">Find and book the perfect venue for your special occasions</p>
          <div className="relative h-64 w-full mb-8">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Party venue"
              fill
              className="rounded-lg object-cover"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Easy Booking</h3>
              <p className="text-sm">Book your perfect venue in minutes</p>
            </div>
            <div className="bg-white/10 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Verified Venues</h3>
              <p className="text-sm">All venues are verified for quality</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="md:w-1/2 p-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          <Tabs defaultValue="customer" onValueChange={(value) => setActiveTab(value as "customer" | "owner")}>
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="customer" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                Customer
              </TabsTrigger>
              <TabsTrigger value="owner" className="flex items-center gap-2">
                <Building className="h-4 w-4" />
                Owner
              </TabsTrigger>
            </TabsList>

            <TabsContent value="customer">
              <Card>
                <CardHeader>
                  <CardTitle>Customer Login</CardTitle>
                  <CardDescription>Login to book party plots and manage your bookings</CardDescription>
                </CardHeader>
                <form onSubmit={handleCustomerLogin}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="customer-email">Email</Label>
                      <Input
                        id="customer-email"
                        type="email"
                        placeholder="your@email.com"
                        value={customerEmail}
                        onChange={(e) => setCustomerEmail(e.target.value)}
                        style={{ color: "black" }} // Explicitly set text color
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="customer-password">Password</Label>
                      <div className="relative">
                        <Input
                          id="customer-password"
                          type={showCustomerPassword ? "text" : "password"}
                          placeholder="••••••••"
                          value={customerPassword}
                          onChange={(e) => setCustomerPassword(e.target.value)}
                          style={{ color: "black" }} // Explicitly set text color
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-0 top-0 h-full px-3"
                          onClick={() => setShowCustomerPassword(!showCustomerPassword)}
                        >
                          {showCustomerPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col space-y-2">
                    <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                      Login
                    </Button>
                    <Button
                      type="button"
                      variant="link"
                      className="text-sm"
                      onClick={() => {
                        setCustomerEmail("customer@example.com")
                        setCustomerPassword("password")
                      }}
                    >
                      Use demo account
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>

            <TabsContent value="owner">
              <Card>
                <CardHeader>
                  <CardTitle>Owner Login</CardTitle>
                  <CardDescription>Login to manage your party plots and bookings</CardDescription>
                </CardHeader>
                <form onSubmit={handleOwnerLogin}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="owner-email">Email</Label>
                      <Input
                        id="owner-email"
                        type="email"
                        placeholder="your@email.com"
                        value={ownerEmail}
                        onChange={(e) => setOwnerEmail(e.target.value)}
                        style={{ color: "black" }} // Explicitly set text color
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="owner-password">Password</Label>
                      <div className="relative">
                        <Input
                          id="owner-password"
                          type={showOwnerPassword ? "text" : "password"}
                          placeholder="••••••••"
                          value={ownerPassword}
                          onChange={(e) => setOwnerPassword(e.target.value)}
                          style={{ color: "black" }} // Explicitly set text color
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-0 top-0 h-full px-3"
                          onClick={() => setShowOwnerPassword(!showOwnerPassword)}
                        >
                          {showOwnerPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col space-y-2">
                    <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                      Login
                    </Button>
                    <Button
                      type="button"
                      variant="link"
                      className="text-sm"
                      onClick={() => {
                        setOwnerEmail("owner@example.com")
                        setOwnerPassword("password")
                      }}
                    >
                      Use demo account
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

