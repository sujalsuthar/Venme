"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import ListingCard from "@/components/listing-card"
import { listings } from "@/lib/data"

export default function ListingsPage() {
  const [filteredListings, setFilteredListings] = useState(listings)
  const [filters, setFilters] = useState({
    location: "",
    priceRange: [1000, 50000],
    capacity: "",
    amenities: {
      parking: false,
      catering: false,
      decoration: false,
      sound: false,
    },
  })

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0)

    let result = [...listings]

    // Filter by location
    if (filters.location) {
      result = result.filter((listing) => listing.location.toLowerCase().includes(filters.location.toLowerCase()))
    }

    // Filter by price range
    result = result.filter(
      (listing) => listing.price >= filters.priceRange[0] && listing.price <= filters.priceRange[1],
    )

    // Filter by capacity
    if (filters.capacity) {
      result = result.filter((listing) => {
        const capacity = Number.parseInt(filters.capacity)
        return listing.capacity >= capacity
      })
    }

    // Filter by amenities
    const selectedAmenities = Object.entries(filters.amenities)
      .filter(([_, selected]) => selected)
      .map(([name]) => name)

    if (selectedAmenities.length > 0) {
      result = result.filter((listing) => selectedAmenities.every((amenity) => listing.amenities.includes(amenity)))
    }

    setFilteredListings(result)
  }, [filters])

  const handleLocationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters((prev) => ({ ...prev, location: e.target.value }))
  }

  const handlePriceChange = (value: number[]) => {
    setFilters((prev) => ({ ...prev, priceRange: value }))
  }

  const handleCapacityChange = (value: string) => {
    setFilters((prev) => ({ ...prev, capacity: value }))
  }

  const handleAmenityChange = (amenity: string, checked: boolean) => {
    setFilters((prev) => ({
      ...prev,
      amenities: {
        ...prev.amenities,
        [amenity]: checked,
      },
    }))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Find Your Perfect Party Plot</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Filters sidebar */}
        <div className="bg-white p-6 rounded-lg shadow-md h-fit lg:sticky lg:top-20">
          <h2 className="text-xl font-semibold mb-4">Filters</h2>

          <div className="space-y-6">
            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="Search by city or area"
                value={filters.location}
                onChange={handleLocationChange}
                className="mt-1"
              />
            </div>

            <div>
              <Label>
                Price Range (₹{filters.priceRange[0]} - ₹{filters.priceRange[1]})
              </Label>
              <Slider
                defaultValue={[1000, 50000]}
                min={1000}
                max={50000}
                step={1000}
                value={filters.priceRange}
                onValueChange={handlePriceChange}
                className="mt-2"
              />
            </div>

            <div>
              <Label htmlFor="capacity">Capacity</Label>
              <Select value={filters.capacity} onValueChange={handleCapacityChange}>
                <SelectTrigger id="capacity" className="mt-1">
                  <SelectValue placeholder="Select capacity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="100">100+ Guests</SelectItem>
                  <SelectItem value="200">200+ Guests</SelectItem>
                  <SelectItem value="500">500+ Guests</SelectItem>
                  <SelectItem value="1000">1000+ Guests</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="mb-2 block">Amenities</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="parking"
                    checked={filters.amenities.parking}
                    onCheckedChange={(checked) => handleAmenityChange("parking", checked as boolean)}
                  />
                  <Label htmlFor="parking">Parking</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="catering"
                    checked={filters.amenities.catering}
                    onCheckedChange={(checked) => handleAmenityChange("catering", checked as boolean)}
                  />
                  <Label htmlFor="catering">Catering</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="decoration"
                    checked={filters.amenities.decoration}
                    onCheckedChange={(checked) => handleAmenityChange("decoration", checked as boolean)}
                  />
                  <Label htmlFor="decoration">Decoration</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="sound"
                    checked={filters.amenities.sound}
                    onCheckedChange={(checked) => handleAmenityChange("sound", checked as boolean)}
                  />
                  <Label htmlFor="sound">Sound System</Label>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Listings grid */}
        <div className="lg:col-span-3">
          {filteredListings.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredListings.map((listing) => (
                <ListingCard key={listing.id} listing={listing} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium">No listings found</h3>
              <p className="text-gray-500 mt-2">Try adjusting your filters</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

