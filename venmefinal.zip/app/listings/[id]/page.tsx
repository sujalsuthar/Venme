"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Calendar, MapPin, Users, Star, Heart, ShoppingCart, Share2, Check, Info, ArrowLeft } from "lucide-react"
import { useFavorites } from "@/lib/hooks/use-favorites"
import { useCart } from "@/lib/hooks/use-cart"
import { useRecentlyViewed } from "@/lib/hooks/use-recently-viewed"
import { listings } from "@/lib/data"
import type { Listing } from "@/lib/types"
import BookingModal from "@/components/booking-modal"
import ListingCard from "@/components/listing-card"
import ReviewForm from "@/components/review-form"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function ListingDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const { addToFavorites, isInFavorites, removeFromFavorites } = useFavorites()
  const { addToCart, isInCart } = useCart()
  const { addToRecentlyViewed } = useRecentlyViewed()

  const [listing, setListing] = useState<Listing | null>(null)
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [similarListings, setSimilarListings] = useState<Listing[]>([])
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Find the listing by ID
    const id = params.id as string
    const foundListing = listings.find((item) => item.id === id)

    if (foundListing) {
      setListing(foundListing)
      addToRecentlyViewed(foundListing)

      // Find similar listings (same location or similar price range)
      const similar = listings
        .filter(
          (item) =>
            item.id !== id &&
            (item.location === foundListing.location || Math.abs(item.price - foundListing.price) < 10000),
        )
        .slice(0, 3)

      setSimilarListings(similar)
    } else {
      router.push("/listings")
    }
  }, [params.id, router, addToRecentlyViewed])

  if (!mounted || !listing) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center items-center min-h-screen">
        <div className="animate-pulse space-y-8 w-full max-w-4xl">
          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
          <div className="h-96 bg-gray-200 rounded"></div>
          <div className="space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    )
  }

  const handleFavoritesToggle = () => {
    if (isInFavorites(listing.id)) {
      removeFromFavorites(listing.id)
      toast({
        title: "Removed from favorites",
        description: `${listing.name} has been removed from your favorites.`,
      })
    } else {
      addToFavorites(listing)
      toast({
        title: "Added to favorites",
        description: `${listing.name} has been added to your favorites.`,
      })
    }
  }

  const handleAddToCart = () => {
    if (!isInCart(listing.id)) {
      setIsLoading(true)
      // Simulate network request
      setTimeout(() => {
        addToCart(listing)
        setIsLoading(false)
        toast({
          title: "Added to cart",
          description: `${listing.name} has been added to your cart.`,
        })
      }, 800)
    } else {
      router.push("/cart")
    }
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: listing.name,
          text: `Check out this amazing party plot: ${listing.name}`,
          url: window.location.href,
        })
        .catch((err) => {
          console.error("Error sharing:", err)
        })
    } else {
      // Fallback for browsers that don't support navigator.share
      navigator.clipboard.writeText(window.location.href)
      toast({
        title: "Link copied",
        description: "The link has been copied to your clipboard.",
      })
    }
  }

  // Mock reviews data
  const reviews = [
    {
      id: 1,
      user: "Rahul M.",
      rating: 5,
      comment: "Amazing venue! Perfect for our wedding reception.",
      date: "2023-12-15",
    },
    {
      id: 2,
      user: "Priya S.",
      rating: 4,
      comment: "Great location and amenities. Staff was very helpful.",
      date: "2023-11-20",
    },
    {
      id: 3,
      user: "Amit K.",
      rating: 5,
      comment: "Excellent service and beautiful venue. Highly recommended!",
      date: "2023-10-05",
    },
    {
      id: 4,
      user: "Neha G.",
      rating: 3,
      comment: "Good venue but parking was limited. Otherwise nice experience.",
      date: "2023-09-12",
    },
  ]

  // Calculate rating distribution
  const ratingCounts = [0, 0, 0, 0, 0]
  reviews.forEach((review) => {
    ratingCounts[review.rating - 1]++
  })

  const totalReviews = reviews.length
  const averageRating = totalReviews > 0 ? reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews : 0

  // Mock FAQs
  const faqs = [
    {
      question: "What is the cancellation policy?",
      answer:
        "Cancellations made 30 days or more before the event date receive a full refund. Cancellations made 15-29 days before receive a 50% refund. Cancellations made less than 15 days before the event are non-refundable.",
    },
    {
      question: "Is catering included in the price?",
      answer:
        "Basic catering services are included in the package. Premium catering options are available at an additional cost. Please contact us for more details on menu options.",
    },
    {
      question: "What is the maximum capacity?",
      answer: `The maximum capacity for ${listing.name} is ${listing.capacity} guests. This includes both indoor and outdoor areas.`,
    },
    {
      question: "Are decorations provided?",
      answer:
        "Basic decorations are included. Custom decoration packages are available at additional cost. You can also bring your own decorations with prior approval.",
    },
    {
      question: "Is parking available?",
      answer:
        "Yes, we provide free parking for up to 100 vehicles. Valet parking services are available for an additional fee.",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="ghost" className="mb-4 pl-0" onClick={() => router.back()}>
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Listings
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="relative h-[400px] rounded-lg overflow-hidden mb-6">
            <Image src={listing.image || "/placeholder.svg"} alt={listing.name} fill className="object-cover" />
            {listing.discount > 0 && (
              <Badge className="absolute top-4 left-4 bg-[#FF6B6B] text-lg py-1 px-3">{listing.discount}% OFF</Badge>
            )}
          </div>

          <div className="mb-6">
            <div className="flex justify-between items-start mb-2">
              <h1 className="text-3xl font-bold">{listing.name}</h1>
              <div className="flex items-center bg-[#FFD700] px-3 py-1 rounded">
                <Star className="h-5 w-5 mr-1 fill-current" />
                <span className="font-semibold">{listing.rating}</span>
              </div>
            </div>
            <p className="flex items-center text-gray-600 mb-4">
              <MapPin className="h-5 w-5 mr-2" />
              {listing.location}
            </p>

            <div className="flex items-baseline mb-4">
              <p className="text-2xl font-bold">₹{(listing.price * (1 - listing.discount / 100)).toLocaleString()}</p>
              {listing.discount > 0 && (
                <p className="text-lg text-gray-500 line-through ml-3">₹{listing.price.toLocaleString()}</p>
              )}
              {listing.discount > 0 && (
                <Badge className="ml-3 bg-green-100 text-green-800">
                  Save ₹{((listing.price * listing.discount) / 100).toLocaleString()}
                </Badge>
              )}
            </div>

            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-gray-500" />
                <span>Capacity: {listing.capacity} guests</span>
              </div>
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-gray-500" />
                <span>Available: Year-round</span>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button onClick={() => setIsBookingModalOpen(true)} className="flex-1 bg-primary hover:bg-primary/90">
                Book Now
              </Button>

              <Button
                variant="outline"
                onClick={handleFavoritesToggle}
                className={cn(
                  "border-[#FF6B6B] text-[#FF6B6B] hover:bg-[#FF6B6B]/10",
                  isInFavorites(listing.id) && "bg-[#FF6B6B]/10",
                )}
              >
                <Heart className={cn("h-5 w-5 mr-2", isInFavorites(listing.id) && "fill-[#FF6B6B]")} />
                {isInFavorites(listing.id) ? "Saved" : "Save"}
              </Button>

              <Button
                variant="outline"
                onClick={handleAddToCart}
                disabled={isLoading}
                className={cn(
                  "border-primary text-primary hover:bg-primary/10",
                  isInCart(listing.id) && "bg-primary/10",
                )}
              >
                {isLoading ? (
                  <div className="h-5 w-5 mr-2 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                ) : (
                  <ShoppingCart className={cn("h-5 w-5 mr-2", isInCart(listing.id) && "fill-primary")} />
                )}
                {isInCart(listing.id) ? "Go to Cart" : "Add to Cart"}
              </Button>

              <Button variant="outline" onClick={handleShare} className="border-gray-300">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <Tabs defaultValue="details" className="mt-8">
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="amenities">Amenities</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="faqs">FAQs</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4">
              <h3 className="text-xl font-semibold">About {listing.name}</h3>
              <p className="text-gray-700">{listing.description}</p>

              <div className="mt-6">
                <h4 className="text-lg font-semibold mb-3">Location</h4>
                <div className="bg-gray-100 h-64 rounded-lg flex items-center justify-center">
                  <p className="text-gray-500">Map view will be displayed here</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="amenities" className="space-y-4">
              <h3 className="text-xl font-semibold mb-4">Amenities & Services</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {listing.amenities.includes("parking") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Parking Available</span>
                  </div>
                )}
                {listing.amenities.includes("catering") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Catering Services</span>
                  </div>
                )}
                {listing.amenities.includes("decoration") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Decoration Services</span>
                  </div>
                )}
                {listing.amenities.includes("sound") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Sound System</span>
                  </div>
                )}
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Air Conditioning</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Backup Power</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>WiFi</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Security Services</span>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="text-lg font-semibold mb-3">Additional Services (Extra Cost)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>Photography & Videography</span>
                  </div>
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>DJ & Entertainment</span>
                  </div>
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>Valet Parking</span>
                  </div>
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>Event Planning</span>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold">Customer Reviews</h3>
                <Button onClick={() => document.getElementById("review-form")?.scrollIntoView({ behavior: "smooth" })}>
                  Write a Review
                </Button>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-4">
                  <div className="text-4xl font-bold mr-4">{averageRating.toFixed(1)}</div>
                  <div className="flex-1">
                    <div className="flex mb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < Math.round(averageRating) ? "text-[#FFD700] fill-[#FFD700]" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-gray-500">{totalReviews} reviews</p>
                  </div>
                </div>

                <div className="space-y-2">
                  {[5, 4, 3, 2, 1].map((rating) => (
                    <div key={rating} className="flex items-center">
                      <div className="w-12 text-sm">{rating} stars</div>
                      <Progress
                        value={totalReviews > 0 ? (ratingCounts[rating - 1] / totalReviews) * 100 : 0}
                        className="h-2 flex-1 mx-2"
                      />
                      <div className="w-8 text-sm text-right">{ratingCounts[rating - 1]}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4 mt-6">
                {reviews.map((review) => (
                  <div key={review.id} className="border-b pb-4">
                    <div className="flex justify-between mb-2">
                      <div className="font-semibold">{review.user}</div>
                      <div className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString()}</div>
                    </div>
                    <div className="flex mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${i < review.rating ? "text-[#FFD700] fill-[#FFD700]" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <p className="text-gray-700">{review.comment}</p>
                  </div>
                ))}
              </div>

              <div id="review-form" className="mt-8">
                <h4 className="text-lg font-semibold mb-4">Write a Review</h4>
                <ReviewForm listingId={listing.id} />
              </div>
            </TabsContent>

            <TabsContent value="faqs">
              <h3 className="text-xl font-semibold mb-4">Frequently Asked Questions</h3>

              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                    <AccordionContent>{faq.answer}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>

              <div className="mt-8 bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold flex items-center">
                  <Info className="h-5 w-5 mr-2 text-blue-500" />
                  Have more questions?
                </h4>
                <p className="mt-2 text-gray-700">
                  Contact our customer support team at support@partyplot.com or call us at +91 98765 43210
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 mb-6 sticky top-20">
            <h3 className="text-xl font-semibold mb-4">Book this Venue</h3>

            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span>Base Price</span>
                <span>₹{listing.price.toLocaleString()}</span>
              </div>
              {listing.discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount ({listing.discount}%)</span>
                  <span>-₹{((listing.price * listing.discount) / 100).toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Service Fee</span>
                <span>₹{(listing.price * 0.05).toLocaleString()}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold">
                <span>Total</span>
                <span>₹{(listing.price * (1 - listing.discount / 100) * 1.05).toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button onClick={() => setIsBookingModalOpen(true)} className="w-full bg-primary hover:bg-primary/90">
                Book Now
              </Button>

              <Button
                variant="outline"
                onClick={handleAddToCart}
                disabled={isLoading}
                className="w-full border-primary text-primary hover:bg-primary/10"
              >
                {isLoading ? (
                  <div className="h-5 w-5 mr-2 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                ) : (
                  <ShoppingCart className="h-5 w-5 mr-2" />
                )}
                Add to Cart
              </Button>
            </div>

            <div className="mt-6 text-sm text-gray-500">
              <p className="flex items-center">
                <Info className="h-4 w-4 mr-2" />
                No payment required to book
              </p>
              <p className="flex items-center mt-1">
                <Info className="h-4 w-4 mr-2" />
                Free cancellation up to 30 days before event
              </p>
            </div>
          </div>

          {similarListings.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-4">Similar Venues</h3>
              <div className="space-y-4">
                {similarListings.map((item) => (
                  <ListingCard key={item.id} listing={item} showActions={false} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        onConfirm={() => {
          addToCart(listing)
          setIsBookingModalOpen(false)
          toast({
            title: "Added to Cart",
            description: `${listing.name} has been added to your cart.`,
          })
        }}
        listings={[listing]}
      />
    </div>
  )
}

