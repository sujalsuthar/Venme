"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Calendar,
  MapPin,
  Users,
  Star,
  Heart,
  ShoppingCart,
  Share2,
  Check,
  Info,
  ArrowLeft,
  Phone,
  Mail,
} from "lucide-react"
import { useFavorites } from "@/lib/providers/favorites-provider"
import { useCart } from "@/lib/hooks/use-cart"
import { useRecentlyViewed } from "@/lib/hooks/use-recently-viewed"
import { useToast } from "@/components/ui/use-toast"
import BookingModal from "@/components/booking-modal"
import NegotiableRequestForm from "@/components/negotiable-request-form"
import { useWatchlist } from "@/lib/hooks/use-watchlist"

export default function LotusListingPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { addToFavorites, isInFavorites, removeFromFavorites } = useFavorites()
  const { addToCart, isInCart } = useCart()
  const { addToRecentlyViewed } = useRecentlyViewed()
  const { addToWatchlist, isInWatchlist, removeFromWatchlist } = useWatchlist()

  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false)
  const [isNegotiationModalOpen, setIsNegotiationModalOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Create a mock listing for The Grand Lotus Banquets
  const listing = {
    id: "lotus-banquet",
    name: "The Grand Lotus Banquets",
    location: "Near Nayara Petrol Pump, Sarkhej-Gandhinagar Highway, Ahmedabad",
    price: 75000,
    rating: 4.9,
    image:
      "https://media-hosting.imagekit.io//63a46695cb304f82/4.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=IYr49cfJpNzNpgCCCW5m~yarhqtZ1ORotWGYYRO30sWA95sm1ZA2t~gP2OsJOkZAGFU7Z471vX7UfFLJcieYiunp3IHx7l0F0WQp4d5~e-Y~9jmLiONnvoVaHy1-6uFWPJvHWTyk2SD5OzxPvccrv0-X7BSxCcAVmjfBWK7z5hsXd1bh333nA-oXBXUgPA37oVmPMPsNdAhSGW7-~JE14YvBAzYReOF~01cnLB413cq5TCpdfp0imw0vMcwZvSvPddyDdp0xV-txEgqCjsbmRC1SwG0DRjP0awbr3uG-XIvd2LHfBVFtvCgW6LjRkH~sf3bPnYhaqpVVKj6hTyLW6w__",
    capacity: 500,
    amenities: ["parking", "catering", "decoration", "sound", "air-conditioning", "wifi"],
    description:
      "The Grand Lotus Banquets is a premier event venue located in the heart of Ahmedabad. Situated near Nayara Petrol Pump, opposite Satyamev Vista on the Off-road Sarkhej-Gandhinagar Highway, our banquet hall is the perfect destination for all your celebrations and special occasions.",
    discount: 10,
    trending: true,
  }

  // Additional images for the gallery
  const galleryImages = [
    "https://media-hosting.imagekit.io//63a46695cb304f82/4.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=IYr49cfJpNzNpgCCCW5m~yarhqtZ1ORotWGYYRO30sWA95sm1ZA2t~gP2OsJOkZAGFU7Z471vX7UfFLJcieYiunp3IHx7l0F0WQp4d5~e-Y~9jmLiONnvoVaHy1-6uFWPJvHWTyk2SD5OzxPvccrv0-X7BSxCcAVmjfBWK7z5hsXd1bh333nA-oXBXUgPA37oVmPMPsNdAhSGW7-~JE14YvBAzYReOF~01cnLB413cq5TCpdfp0imw0vMcwZvSvPddyDdp0xV-txEgqCjsbmRC1SwG0DRjP0awbr3uG-XIvd2LHfBVFtvCgW6LjRkH~sf3bPnYhaqpVVKj6hTyLW6w__",
    "https://media-hosting.imagekit.io//4d0e9f7ade984383/2.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=Czqy-FFwJZ5OqlyUb-7cxJLVDYXPPvyb8N~Nsa4iwXsifffG9nSnQnNFkwnPJeVHEBDnkzU1cvsAMJPH5RghaXhQR-pbn7PH95zQO1l3PsNmDacgk0TN3f0EgbRpccS5XKJqvmRByIe~K7nZ8ylEb8dgmrwZ3h7eAaZH9y0omTT7RpgHip4ZQyZdAVxBalJ19~MVSIuE-MdSs-Cv~2k91dTUjp2mv8azeOi48dmdM9aoku2VivIg4O~1hAmGwXUB5LiHi5FbcnkU2Hml-zugzT-QA5GTPmar1WdQjqf9WsI0RdSG7VzFGu96sv0uxnke~I1~EPmDlU8RrBwRe4lT2g__",
    "https://media-hosting.imagekit.io//2ba1438b192b4038/1.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=nnug668lshxMZnmXLcVyiSPq5yCH63lQTdj2WLgWuYG4LhEDKXvUvTaRtceEckcIC8GfhKeszZIX4LQDzIzkESm~L5qTLCEgGkqEHflQAX60lsLyONeU0aeupBEQGZiWvE3HBAuTEEsZ5LDeXW6CkDeQxbJpPHLIihA9C26cqeWQbaMn3UCCHQzx7xEhcs4dYpiDruASL3kg-CE75i4H7In~8bPdk2SkW1BPa7YCaRFG1gJRfYzoGUlajlAgwHS9JJqWDivRk7c14-DRQa-F9VJXF2LHDwJNnitJHov0yjS5A6aa9ta4KJbulOcLN4CV-NHB9vPL4w6N-v4u7tn79w__",
    "https://media-hosting.imagekit.io//0488c6bd86a04e2c/3.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=aDR2Rfc-sgY3FAsfAeBmcWALg6-4kdWlJ-L8nFxnfjy8lYxzmNOY231AUa-6CUvvEQ8FxOE5JlSaa~v6ovIfGsnGN0Jd08xNB8poBOjiDjudc0Xo4LRN5-0oO3shB6l-SA93NiAq61~uAGURzLyRu9KMYH75BdSFjAIc~lid69OCnI6gNRg3yl82FH17XIMLeO53mUwtRWXyfTwjJdqod1a2ohHZq9fMChGKrcojmSn4Pz3tJZphbtXrSgagrse2P4r0f5ToNkIhynsoPhOlERHWyxHZm4l6CQhw7V1xc2TuGsHjKJeR~voKNxZRkAZCnk7wgxFPROdRoIac79b48Q__",
    "https://media-hosting.imagekit.io//ea7687224c804b57/5.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=anWXGFJGsWRkJv9PsltSWsIErapIh~7gcRAH8sYUMQfO~sXI7mTz3Y~btdm1hi-5rKOd6tJ4GV8BkihKIBAOcmtRIGHYaFdVGbg6THqEyt2iN3HSzZBJhPdgvOyyTw0MxasS07dI4MObRC1MC7Z3YZ68OlmAEOq3R0yhh0V8dDX0rYa6hypCmmFidSJycwMntAAkk3wmCimyVqwz3C1fgvyDcbYmL3oAi-aXvhnm2CFRgseldMYaAaVPz6VcrOieD1kDvvSYEXp8WXRysG62ps0vHBbuLfiJlrfQ27SQqceb~kkON0vWHb6OA5bYLJQRZvbnT4Ergigv1s6qJhBzvw__",
    "https://media-hosting.imagekit.io//120fb344eaff4f0a/6.jpg?Expires=1836620424&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=tCvVVkDt7Bi6T1L18-agbMgWqlKs~NoCOkSkO0fBmpiWvUksxZT-S0eRAdomsiTY5B~spnXQIMI-r7jMpAX8ESq2eyT4GbM1vJW3jf8vslT1a6Mb2uXYWRYVMf63w7gIfKCO7uIvQ1hwxGoaUHebRUuL~lycuuH6ki1etkCX~oG2~gYKolxTaVcg7gBvVio68iQVHNN3iSx~3T9r1tucMWkN7v~AVeMnzMeZ0GLacSkAzkAYRgtz9HMy-kcn1iPjtrSd6n0yqi6MnGe2FlChjDoBP8t8djg00fP3EbXFLYLz0GrJmauEjYkpR6r36h5JhQjboMB9BBdD1MnIz81TLQ__",
  ]

  addToRecentlyViewed(listing)

  const handleFavoritesToggle = () => {
    if (isInFavorites(listing.id)) {
      removeFromFavorites(listing.id)
      toast({
        title: "Removed from favorites",
        description: `${listing.name} has been removed from your favorites.`,
      })
    } else {
      addToFavorites(listing)
      toast({
        title: "Added to favorites",
        description: `${listing.name} has been added to your favorites.`,
      })
    }
  }

  const handleAddToCart = () => {
    if (!isInCart(listing.id)) {
      setIsLoading(true)
      // Simulate network request
      setTimeout(() => {
        addToCart(listing)
        setIsLoading(false)
        toast({
          title: "Added to cart",
          description: `${listing.name} has been added to your cart.`,
        })
      }, 800)
    } else {
      router.push("/cart")
    }
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: listing.name,
          text: `Check out this amazing party plot: ${listing.name}`,
          url: window.location.href,
        })
        .catch((err) => {
          console.error("Error sharing:", err)
        })
    } else {
      // Fallback for browsers that don't support navigator.share
      navigator.clipboard.writeText(window.location.href)
      toast({
        title: "Link copied",
        description: "The link has been copied to your clipboard.",
      })
    }
  }

  const handleNegotiateRequest = () => {
    setIsNegotiationModalOpen(true)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="ghost" className="mb-4 pl-0" onClick={() => router.back()}>
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Listings
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="relative h-[400px] rounded-lg overflow-hidden mb-6">
            <Image src={listing.image || "/placeholder.svg"} alt={listing.name} fill className="object-cover" />
            {listing.discount > 0 && (
              <Badge className="absolute top-4 left-4 bg-accent text-primary text-lg py-1 px-3">
                {listing.discount}% OFF
              </Badge>
            )}
          </div>

          <div className="mb-6">
            <div className="flex justify-between items-start mb-2">
              <h1 className="text-3xl font-bold">{listing.name}</h1>
              <div className="flex items-center bg-[#FFD700] px-3 py-1 rounded">
                <Star className="h-5 w-5 mr-1 fill-current" />
                <span className="font-semibold">{listing.rating}</span>
              </div>
            </div>
            <p className="flex items-center text-gray-600 mb-4">
              <MapPin className="h-5 w-5 mr-2" />
              {listing.location}
            </p>

            <div className="flex items-baseline mb-4">
              <p className="text-2xl font-bold">₹{(listing.price * (1 - listing.discount / 100)).toLocaleString()}</p>
              {listing.discount > 0 && (
                <p className="text-lg text-gray-500 line-through ml-3">₹{listing.price.toLocaleString()}</p>
              )}
              {listing.discount > 0 && (
                <Badge className="ml-3 bg-green-100 text-green-800">
                  Save ₹{((listing.price * listing.discount) / 100).toLocaleString()}
                </Badge>
              )}
            </div>

            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-gray-500" />
                <span>Capacity: {listing.capacity} guests</span>
              </div>
              <div className="flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-gray-500" />
                <span>Available: Year-round</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <Button onClick={() => setIsBookingModalOpen(true)} className="bg-primary hover:bg-primary/90">
                Book Now
              </Button>

              <Button
                variant="outline"
                onClick={handleFavoritesToggle}
                className={`${isInFavorites(listing.id) ? "bg-accent/10 border-accent text-primary" : "border-accent text-primary hover:bg-accent/10"}`}
              >
                <Heart className={`h-5 w-5 mr-2 ${isInFavorites(listing.id) && "fill-accent"}`} />
                {isInFavorites(listing.id) ? "Saved" : "Save"}
              </Button>

              <Button
                variant="outline"
                onClick={handleAddToCart}
                disabled={isLoading}
                className={`${isInCart(listing.id) ? "bg-primary/10 border-primary" : "border-primary text-primary hover:bg-primary/10"}`}
              >
                {isLoading ? (
                  <div className="h-5 w-5 mr-2 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                ) : (
                  <ShoppingCart className={`h-5 w-5 mr-2 ${isInCart(listing.id) && "fill-primary"}`} />
                )}
                {isInCart(listing.id) ? "Go to Cart" : "Add to Cart"}
              </Button>

              <Button
                variant="outline"
                onClick={handleNegotiateRequest}
                className="border-primary text-primary hover:bg-primary/10"
              >
                <Phone className="h-5 w-5 mr-2" />
                Negotiate Price
              </Button>

              <Button variant="outline" onClick={handleShare} className="border-gray-300">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>

          <Tabs defaultValue="details" className="mt-8">
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="amenities">Amenities</TabsTrigger>
              <TabsTrigger value="gallery">Gallery</TabsTrigger>
              <TabsTrigger value="contact">Contact</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4">
              <h3 className="text-xl font-semibold">About {listing.name}</h3>
              <p className="text-gray-700">{listing.description}</p>

              <div className="mt-6">
                <h4 className="text-lg font-semibold mb-3">Location</h4>
                <div className="bg-gray-100 h-64 rounded-lg flex items-center justify-center">
                  <p className="text-gray-500">Map view will be displayed here</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="amenities" className="space-y-4">
              <h3 className="text-xl font-semibold mb-4">Amenities & Services</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {listing.amenities.includes("parking") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Parking Available</span>
                  </div>
                )}
                {listing.amenities.includes("catering") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Catering Services</span>
                  </div>
                )}
                {listing.amenities.includes("decoration") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Decoration Services</span>
                  </div>
                )}
                {listing.amenities.includes("sound") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Sound System</span>
                  </div>
                )}
                {listing.amenities.includes("air-conditioning") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>Air Conditioning</span>
                  </div>
                )}
                {listing.amenities.includes("wifi") && (
                  <div className="flex items-center">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    <span>WiFi</span>
                  </div>
                )}
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Backup Power</span>
                </div>
                <div className="flex items-center">
                  <Check className="h-5 w-5 mr-2 text-green-500" />
                  <span>Security Services</span>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="text-lg font-semibold mb-3">Additional Services (Extra Cost)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>Photography & Videography</span>
                  </div>
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>DJ & Entertainment</span>
                  </div>
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>Valet Parking</span>
                  </div>
                  <div className="flex items-center">
                    <Info className="h-5 w-5 mr-2 text-blue-500" />
                    <span>Event Planning</span>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="gallery">
              <h3 className="text-xl font-semibold mb-4">Gallery</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {galleryImages.map((image, index) => (
                  <div key={index} className="relative aspect-video rounded-lg overflow-hidden">
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${listing.name} - Image ${index + 1}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="contact">
              <h3 className="text-xl font-semibold mb-4">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Phone className="h-5 w-5 mr-3 text-primary" />
                  <div>
                    <p className="font-medium">Phone</p>
                    <p>+91 98765 43210</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Mail className="h-5 w-5 mr-3 text-primary" />
                  <div>
                    <p className="font-medium">Email</p>
                    <p>info@grandlotusbanquets.com</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 mr-3 text-primary mt-1" />
                  <div>
                    <p className="font-medium">Address</p>
                    <p>{listing.location}</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 mb-6 sticky top-20">
            <h3 className="text-xl font-semibold mb-4">Book this Venue</h3>

            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span>Base Price</span>
                <span>₹{listing.price.toLocaleString()}</span>
              </div>
              {listing.discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount ({listing.discount}%)</span>
                  <span>-₹{((listing.price * listing.discount) / 100).toLocaleString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Service Fee</span>
                <span>₹{(listing.price * 0.05).toLocaleString()}</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-bold">
                <span>Total</span>
                <span>₹{(listing.price * (1 - listing.discount / 100) * 1.05).toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-3">
              <Button onClick={() => setIsBookingModalOpen(true)} className="w-full bg-primary hover:bg-primary/90">
                Book Now
              </Button>

              <Button
                variant="outline"
                onClick={handleNegotiateRequest}
                className="w-full border-primary text-primary hover:bg-primary/10"
              >
                <Phone className="h-5 w-5 mr-2" />
                Negotiate Price
              </Button>
            </div>

            <div className="mt-6 text-sm text-gray-500">
              <p className="flex items-center">
                <Info className="h-4 w-4 mr-2" />
                No payment required to book
              </p>
              <p className="flex items-center mt-1">
                <Info className="h-4 w-4 mr-2" />
                Free cancellation up to 30 days before event
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        onConfirm={() => {
          addToCart(listing)
          setIsBookingModalOpen(false)
          toast({
            title: "Added to Cart",
            description: `${listing.name} has been added to your cart.`,
          })
        }}
        listings={[listing]}
      />

      {/* Negotiation Request Modal */}
      <NegotiableRequestForm
        isOpen={isNegotiationModalOpen}
        onClose={() => setIsNegotiationModalOpen(false)}
        listingId={listing.id}
        listingName={listing.name}
      />
    </div>
  )
}

